using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RigLedger.Models;
using RigLedger.Services;

namespace RigLedger.ViewModels;

public partial class BuildsViewModel : ObservableObject, IRefreshable
{
    private readonly DatabaseService _db;
    private bool _isNewBuild;
    private int _editingPartId;

    public ObservableCollection<BuildModel> Builds { get; } = new();
    public ObservableCollection<PartModel> Parts { get; } = new();
    public ObservableCollection<string> PartTypes { get; } = new(PartCatalog.Types);

    [ObservableProperty] private BuildModel _selectedBuild;
    [ObservableProperty] private string _statusMessage;

    // Build editor
    [ObservableProperty] private bool _isBuildEditorOpen;
    [ObservableProperty] private string _buildEditorTitle = "New build";
    [ObservableProperty] private string _buildNameInput = string.Empty;
    [ObservableProperty] private string _buildNotesInput = string.Empty;
    [ObservableProperty] private string _buildError;

    // Part editor
    [ObservableProperty] private bool _isPartEditorOpen;
    [ObservableProperty] private string _partEditorTitle = "Add part";
    [ObservableProperty] private string _editPartType = "CPU";
    [ObservableProperty] private string _editBrand = string.Empty;
    [ObservableProperty] private string _editModel = string.Empty;
    [ObservableProperty] private string _editPrice = string.Empty;
    [ObservableProperty] private string _editSpecA = string.Empty;
    [ObservableProperty] private string _editSpecB = string.Empty;
    [ObservableProperty] private string _editWatts = string.Empty;
    [ObservableProperty] private string _partError;
    [ObservableProperty] private string _specALabel = PartCatalog.SpecALabel("CPU");
    [ObservableProperty] private string _specBLabel = PartCatalog.SpecBLabel("CPU");
    [ObservableProperty] private string _wattsLabel = PartCatalog.WattsLabel("CPU");
    [ObservableProperty] private string _wattsHint = PartCatalog.WattsHint("CPU");

    public bool HasSelection => SelectedBuild != null;
    public string SelectedBuildName => SelectedBuild?.Name ?? "No build selected";
    public string SelectedBuildNotes => string.IsNullOrWhiteSpace(SelectedBuild?.Notes)
        ? "No notes on this build yet."
        : SelectedBuild.Notes;
    public string TotalCostDisplay => SelectedBuild == null ? "—" : SelectedBuild.TotalCostDisplay;
    public string PowerDisplay => SelectedBuild == null ? "—" : SelectedBuild.PowerDisplay;
    public string HeadroomDisplay => SelectedBuild == null ? "—" : SelectedBuild.HeadroomDisplay;
    public string PartCountDisplay => SelectedBuild == null ? "—" : SelectedBuild.PartCountDisplay;

    public IRelayCommand NewBuildCommand { get; }
    public IRelayCommand EditBuildCommand { get; }
    public IRelayCommand SaveBuildCommand { get; }
    public IRelayCommand CancelBuildCommand { get; }
    public IRelayCommand DuplicateBuildCommand { get; }
    public IRelayCommand DeleteBuildCommand { get; }
    public IRelayCommand AddPartCommand { get; }
    public IRelayCommand<PartModel> EditPartCommand { get; }
    public IRelayCommand<PartModel> DeletePartCommand { get; }
    public IRelayCommand SavePartCommand { get; }
    public IRelayCommand CancelPartCommand { get; }

    public BuildsViewModel(DatabaseService db)
    {
        _db = db;

        NewBuildCommand = new RelayCommand(OpenNewBuild);
        EditBuildCommand = new RelayCommand(OpenEditBuild);
        SaveBuildCommand = new AsyncRelayCommand(SaveBuildAsync);
        CancelBuildCommand = new RelayCommand(() => { IsBuildEditorOpen = false; BuildError = null; });
        DuplicateBuildCommand = new AsyncRelayCommand(DuplicateBuildAsync);
        DeleteBuildCommand = new AsyncRelayCommand(DeleteBuildAsync);

        AddPartCommand = new RelayCommand(OpenNewPart);
        EditPartCommand = new RelayCommand<PartModel>(OpenEditPart);
        DeletePartCommand = new AsyncRelayCommand<PartModel>(DeletePartAsync);
        SavePartCommand = new AsyncRelayCommand(SavePartAsync);
        CancelPartCommand = new RelayCommand(() => { IsPartEditorOpen = false; PartError = null; });
    }

    public async Task LoadAsync()
    {
        try
        {
            StatusMessage = null;
            var previousId = SelectedBuild?.Id ?? 0;

            var list = await _db.GetBuildsAsync();
            Builds.Clear();
            foreach (var b in list) Builds.Add(b);

            var next = Builds.FirstOrDefault(b => b.Id == previousId) ?? Builds.FirstOrDefault();
            if (ReferenceEquals(next, SelectedBuild))
            {
                await LoadPartsAsync();
                RefreshSummary();
            }
            else
            {
                SelectedBuild = next;
            }

            if (SelectedBuild == null)
            {
                Parts.Clear();
                RefreshSummary();
            }
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not load builds: " + ex.Message;
        }
    }

    partial void OnSelectedBuildChanged(BuildModel value)
    {
        IsPartEditorOpen = false;
        IsBuildEditorOpen = false;
        RefreshSummary();
        _ = LoadPartsAsync();
    }

    partial void OnEditPartTypeChanged(string value)
    {
        var type = string.IsNullOrWhiteSpace(value) ? "CPU" : value;
        SpecALabel = PartCatalog.SpecALabel(type);
        SpecBLabel = PartCatalog.SpecBLabel(type);
        WattsLabel = PartCatalog.WattsLabel(type);
        WattsHint = PartCatalog.WattsHint(type);
    }

    private void RefreshSummary()
    {
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(SelectedBuildName));
        OnPropertyChanged(nameof(SelectedBuildNotes));
        OnPropertyChanged(nameof(TotalCostDisplay));
        OnPropertyChanged(nameof(PowerDisplay));
        OnPropertyChanged(nameof(HeadroomDisplay));
        OnPropertyChanged(nameof(PartCountDisplay));
    }

    private async Task LoadPartsAsync()
    {
        try
        {
            Parts.Clear();
            if (SelectedBuild == null) return;

            var parts = await _db.GetPartsAsync(SelectedBuild.Id);
            foreach (var p in parts) Parts.Add(p);
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not load parts: " + ex.Message;
        }
    }

    // -------------------------------------------------------------- build editor

    private void OpenNewBuild()
    {
        _isNewBuild = true;
        BuildEditorTitle = "New build";
        BuildNameInput = string.Empty;
        BuildNotesInput = string.Empty;
        BuildError = null;
        IsPartEditorOpen = false;
        IsBuildEditorOpen = true;
    }

    private void OpenEditBuild()
    {
        if (SelectedBuild == null) return;
        _isNewBuild = false;
        BuildEditorTitle = "Rename build";
        BuildNameInput = SelectedBuild.Name;
        BuildNotesInput = SelectedBuild.Notes;
        BuildError = null;
        IsPartEditorOpen = false;
        IsBuildEditorOpen = true;
    }

    private async Task SaveBuildAsync()
    {
        if (string.IsNullOrWhiteSpace(BuildNameInput))
        {
            BuildError = "Give the build a name first.";
            return;
        }

        try
        {
            BuildError = null;
            int targetId;

            if (_isNewBuild)
            {
                targetId = await _db.InsertBuildAsync(BuildNameInput.Trim(), BuildNotesInput?.Trim());
            }
            else
            {
                if (SelectedBuild == null) return;
                targetId = SelectedBuild.Id;
                await _db.UpdateBuildAsync(targetId, BuildNameInput.Trim(), BuildNotesInput?.Trim());
            }

            IsBuildEditorOpen = false;
            await LoadAsync();
            SelectBuildById(targetId);
        }
        catch (Exception ex)
        {
            BuildError = "Could not save the build: " + ex.Message;
        }
    }

    private async Task DuplicateBuildAsync()
    {
        if (SelectedBuild == null) return;
        try
        {
            var newId = await _db.DuplicateBuildAsync(SelectedBuild.Id, SelectedBuild.Name + " (copy)");
            await LoadAsync();
            SelectBuildById(newId);
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not duplicate the build: " + ex.Message;
        }
    }

    private async Task DeleteBuildAsync()
    {
        if (SelectedBuild == null) return;

        var answer = MessageBox.Show(
            "Delete \"" + SelectedBuild.Name + "\" with all of its parts, benchmarks and price history?",
            "Delete build", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (answer != MessageBoxResult.Yes) return;

        try
        {
            await _db.DeleteBuildAsync(SelectedBuild.Id);
            SelectedBuild = null;
            await LoadAsync();
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not delete the build: " + ex.Message;
        }
    }

    private void SelectBuildById(int id)
    {
        var match = Builds.FirstOrDefault(b => b.Id == id);
        if (match != null) SelectedBuild = match;
    }

    // -------------------------------------------------------------- part editor

    private void OpenNewPart()
    {
        if (SelectedBuild == null) return;
        _editingPartId = 0;
        PartEditorTitle = "Add part";
        EditPartType = "CPU";
        EditBrand = string.Empty;
        EditModel = string.Empty;
        EditPrice = string.Empty;
        EditSpecA = string.Empty;
        EditSpecB = string.Empty;
        EditWatts = string.Empty;
        PartError = null;
        IsBuildEditorOpen = false;
        IsPartEditorOpen = true;
    }

    private void OpenEditPart(PartModel part)
    {
        if (part == null) return;
        _editingPartId = part.Id;
        PartEditorTitle = "Edit part";
        EditPartType = part.PartType;
        EditBrand = part.Brand;
        EditModel = part.Model;
        EditPrice = part.Price.ToString("0.##", CultureInfo.InvariantCulture);
        EditSpecA = part.SpecA;
        EditSpecB = part.SpecB;
        EditWatts = part.Watts.ToString(CultureInfo.InvariantCulture);
        PartError = null;
        IsBuildEditorOpen = false;
        IsPartEditorOpen = true;
    }

    private async Task SavePartAsync()
    {
        if (SelectedBuild == null) return;

        if (string.IsNullOrWhiteSpace(EditModel) && string.IsNullOrWhiteSpace(EditBrand))
        {
            PartError = "Enter at least a brand or a model name.";
            return;
        }

        double price = 0;
        if (!string.IsNullOrWhiteSpace(EditPrice) &&
            !double.TryParse(EditPrice.Trim(), NumberStyles.Any, CultureInfo.InvariantCulture, out price))
        {
            PartError = "Price must be a number, for example 42000.";
            return;
        }
        if (price < 0)
        {
            PartError = "Price cannot be negative.";
            return;
        }

        var watts = 0;
        if (!string.IsNullOrWhiteSpace(EditWatts) &&
            !int.TryParse(EditWatts.Trim(), NumberStyles.Integer, CultureInfo.InvariantCulture, out watts))
        {
            PartError = "Wattage must be a whole number, for example 105.";
            return;
        }
        if (watts < 0)
        {
            PartError = "Wattage cannot be negative.";
            return;
        }

        var part = new PartModel
        {
            Id = _editingPartId,
            BuildId = SelectedBuild.Id,
            PartType = EditPartType,
            Brand = (EditBrand ?? string.Empty).Trim(),
            Model = (EditModel ?? string.Empty).Trim(),
            Price = price,
            SpecA = (EditSpecA ?? string.Empty).Trim(),
            SpecB = (EditSpecB ?? string.Empty).Trim(),
            Watts = watts
        };

        try
        {
            PartError = null;

            if (_editingPartId == 0)
            {
                await _db.InsertPartAsync(part);
            }
            else
            {
                var existing = Parts.FirstOrDefault(p => p.Id == _editingPartId);
                part.TargetPrice = existing?.TargetPrice ?? 0;
                await _db.UpdatePartAsync(part);
            }

            IsPartEditorOpen = false;
            await LoadAsync();
        }
        catch (Exception ex)
        {
            PartError = "Could not save the part: " + ex.Message;
        }
    }

    private async Task DeletePartAsync(PartModel part)
    {
        if (part == null) return;

        var answer = MessageBox.Show(
            "Remove \"" + part.Title + "\" and its price history from this build?",
            "Remove part", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (answer != MessageBoxResult.Yes) return;

        try
        {
            await _db.DeletePartAsync(part.Id);
            await LoadAsync();
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not remove the part: " + ex.Message;
        }
    }
}
