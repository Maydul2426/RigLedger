﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RigLedger.Models;
using RigLedger.Services;

namespace RigLedger.ViewModels;

public partial class PricesViewModel : ObservableObject, IRefreshable
{
    private readonly DatabaseService _db;
    private readonly PriceFetchService _fetch;

    private double _fetchedPrice;
    private string _fetchedShop = string.Empty;

    public ObservableCollection<PartModel> Parts { get; } = new();
    public ObservableCollection<PriceEntry> Entries { get; } = new();
    public ObservableCollection<string> RefreshLog { get; } = new();

    [ObservableProperty] private PartModel _selectedPart;
    [ObservableProperty] private List<ChartPoint> _chartPoints = new();
    [ObservableProperty] private double _chartTarget;
    [ObservableProperty] private string _statusMessage;

    // Target editor
    [ObservableProperty] private string _targetInput = string.Empty;
    [ObservableProperty] private string _targetError;

    // Entry editor
    [ObservableProperty] private bool _isEntryEditorOpen;
    [ObservableProperty] private string _entryShop = string.Empty;
    [ObservableProperty] private string _entryPrice = string.Empty;
    [ObservableProperty] private string _entryDate = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    [ObservableProperty] private string _entryError;

    // Live price fetch
    [ObservableProperty] private string _urlInput = string.Empty;
    [ObservableProperty] private string _urlMessage;
    [ObservableProperty] private bool _isFetching;
    [ObservableProperty] private bool _hasFetchedPrice;
    [ObservableProperty] private string _fetchedSummary;

    // Refresh all
    [ObservableProperty] private bool _isRefreshingAll;
    [ObservableProperty] private double _progressValue;
    [ObservableProperty] private double _progressMaximum = 1;
    [ObservableProperty] private string _progressText;

    public bool IsIdle => !IsFetching && !IsRefreshingAll;

    public bool HasSelection => SelectedPart != null;
    public string PartTitle => SelectedPart?.Title ?? "No part selected";
    public string PartSubtitle => SelectedPart == null
        ? "Pick a part on the left to log and track its price."
        : SelectedPart.PartType + "  ·  " + (string.IsNullOrWhiteSpace(SelectedPart.BuildName) ? "Unassigned" : SelectedPart.BuildName);
    public string LatestDisplay => SelectedPart?.LatestDisplay ?? "—";
    public string LowestDisplay => SelectedPart?.LowestDisplay ?? "—";
    public string TargetDisplay => SelectedPart?.TargetDisplay ?? "—";
    public string EntryCountDisplay => SelectedPart?.EntryCountDisplay ?? "0 entries";
    public bool ShowTargetBadge => SelectedPart != null && SelectedPart.HasTarget && SelectedPart.LatestPrice > 0;
    public bool TargetHit => SelectedPart != null && SelectedPart.TargetHit;
    public string TargetBadgeText => SelectedPart == null
        ? string.Empty
        : (SelectedPart.TargetHit ? "At or below target" : "Still above target");

    public IRelayCommand OpenEntryEditorCommand { get; }
    public IRelayCommand CloseEntryEditorCommand { get; }
    public IRelayCommand SaveEntryCommand { get; }
    public IRelayCommand<PriceEntry> DeleteEntryCommand { get; }
    public IRelayCommand SaveTargetCommand { get; }
    public IRelayCommand ClearTargetCommand { get; }
    public IRelayCommand SaveUrlCommand { get; }
    public IRelayCommand FetchPriceCommand { get; }
    public IRelayCommand ConfirmFetchedCommand { get; }
    public IRelayCommand DismissFetchedCommand { get; }
    public IRelayCommand RefreshAllCommand { get; }

    public PricesViewModel(DatabaseService db, PriceFetchService fetch)
    {
        _db = db;
        _fetch = fetch;

        OpenEntryEditorCommand = new RelayCommand(OpenEntryEditor);
        CloseEntryEditorCommand = new RelayCommand(() => { IsEntryEditorOpen = false; EntryError = null; });
        SaveEntryCommand = new AsyncRelayCommand(SaveEntryAsync);
        DeleteEntryCommand = new AsyncRelayCommand<PriceEntry>(DeleteEntryAsync);
        SaveTargetCommand = new AsyncRelayCommand(SaveTargetAsync);
        ClearTargetCommand = new AsyncRelayCommand(ClearTargetAsync);

        SaveUrlCommand = new AsyncRelayCommand(SaveUrlAsync);
        FetchPriceCommand = new AsyncRelayCommand(FetchPriceAsync);
        ConfirmFetchedCommand = new AsyncRelayCommand(ConfirmFetchedAsync);
        DismissFetchedCommand = new RelayCommand(() => { HasFetchedPrice = false; FetchedSummary = null; });
        RefreshAllCommand = new AsyncRelayCommand(RefreshAllAsync);
    }

    partial void OnIsFetchingChanged(bool value) => OnPropertyChanged(nameof(IsIdle));
    partial void OnIsRefreshingAllChanged(bool value) => OnPropertyChanged(nameof(IsIdle));

    public async Task LoadAsync()
    {
        try
        {
            StatusMessage = null;
            var previousId = SelectedPart?.Id ?? 0;

            var parts = await _db.GetAllPartsAsync();
            Parts.Clear();
            foreach (var p in parts) Parts.Add(p);

            var next = Parts.FirstOrDefault(p => p.Id == previousId) ?? Parts.FirstOrDefault();
            if (ReferenceEquals(next, SelectedPart))
            {
                await LoadEntriesAsync();
                RefreshSummary();
            }
            else
            {
                SelectedPart = next;
            }

            if (SelectedPart == null)
            {
                Entries.Clear();
                ChartPoints = new List<ChartPoint>();
                UrlInput = string.Empty;
                RefreshSummary();
            }
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not load tracked parts: " + ex.Message;
        }
    }

    partial void OnSelectedPartChanged(PartModel value)
    {
        IsEntryEditorOpen = false;
        TargetError = null;
        UrlMessage = null;
        HasFetchedPrice = false;
        FetchedSummary = null;

        UrlInput = value?.ProductUrl ?? string.Empty;

        TargetInput = value != null && value.TargetPrice > 0
            ? value.TargetPrice.ToString("0.##", CultureInfo.InvariantCulture)
            : string.Empty;
        ChartTarget = value?.TargetPrice ?? 0;
        RefreshSummary();
        _ = LoadEntriesAsync();
    }

    private void RefreshSummary()
    {
        OnPropertyChanged(nameof(HasSelection));
        OnPropertyChanged(nameof(PartTitle));
        OnPropertyChanged(nameof(PartSubtitle));
        OnPropertyChanged(nameof(LatestDisplay));
        OnPropertyChanged(nameof(LowestDisplay));
        OnPropertyChanged(nameof(TargetDisplay));
        OnPropertyChanged(nameof(EntryCountDisplay));
        OnPropertyChanged(nameof(ShowTargetBadge));
        OnPropertyChanged(nameof(TargetHit));
        OnPropertyChanged(nameof(TargetBadgeText));
    }

    private async Task LoadEntriesAsync()
    {
        try
        {
            Entries.Clear();
            ChartPoints = new List<ChartPoint>();
            if (SelectedPart == null) return;

            var entries = await _db.GetPricesAsync(SelectedPart.Id);
            foreach (var e in entries.OrderByDescending(e => e.EntryDate)) Entries.Add(e);

            ChartPoints = entries
                .Select(e => new ChartPoint { Label = e.EntryDate, Value = e.Price })
                .ToList();
            ChartTarget = SelectedPart.TargetPrice;
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not load price history: " + ex.Message;
        }
    }

    // -------------------------------------------------------------- product URL

    private async Task SaveUrlAsync()
    {
        if (SelectedPart == null) return;

        var url = (UrlInput ?? string.Empty).Trim();

        if (url.Length > 0 &&
            (!Uri.TryCreate(url, UriKind.Absolute, out var uri) ||
             (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps)))
        {
            UrlMessage = "That is not a valid web address. It should start with https://";
            return;
        }

        try
        {
            UrlMessage = null;
            await _db.UpdatePartUrlAsync(SelectedPart.Id, url);
            SelectedPart.ProductUrl = url;
            UrlMessage = url.Length == 0 ? "Product URL cleared." : "Product URL saved.";
        }
        catch (Exception ex)
        {
            UrlMessage = "Could not save the URL: " + ex.Message;
        }
    }

    private async Task FetchPriceAsync()
    {
        if (SelectedPart == null || !IsIdle) return;

        var url = (UrlInput ?? string.Empty).Trim();
        if (url.Length == 0)
        {
            UrlMessage = "Add a product URL first, then press Save URL.";
            return;
        }

        HasFetchedPrice = false;
        FetchedSummary = null;
        UrlMessage = "Fetching the page…";
        IsFetching = true;

        try
        {
            var result = await _fetch.FetchAsync(url);

            if (!result.Success)
            {
                UrlMessage = result.Message;
                return;
            }

            _fetchedPrice = result.Price;
            _fetchedShop = result.Shop;
            FetchedSummary = "Found " + Money.Format(result.Price) + " at " + result.Shop +
                             " (via " + result.Method + ").";
            HasFetchedPrice = true;
            UrlMessage = null;
        }
        catch (Exception ex)
        {
            UrlMessage = "Could not fetch the price: " + ex.Message;
        }
        finally
        {
            IsFetching = false;
        }
    }

    private async Task ConfirmFetchedAsync()
    {
        if (SelectedPart == null || !HasFetchedPrice) return;

        try
        {
            await _db.InsertPriceAsync(new PriceEntry
            {
                PartId = SelectedPart.Id,
                Shop = _fetchedShop,
                Price = _fetchedPrice,
                EntryDate = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
            });

            HasFetchedPrice = false;
            FetchedSummary = null;
            UrlMessage = "Logged as a new price entry.";
            await LoadAsync();
        }
        catch (Exception ex)
        {
            UrlMessage = "Could not save the entry: " + ex.Message;
        }
    }

    // -------------------------------------------------------------- refresh all

    private async Task RefreshAllAsync()
    {
        if (!IsIdle) return;

        var targets = Parts.Where(p => p.HasUrl).ToList();

        RefreshLog.Clear();
        HasFetchedPrice = false;
        FetchedSummary = null;

        if (targets.Count == 0)
        {
            ProgressText = "No tracked part has a product URL yet. Add one above first.";
            return;
        }

        IsRefreshingAll = true;
        ProgressMaximum = targets.Count;
        ProgressValue = 0;

        var logged = 0;

        try
        {
            for (var i = 0; i < targets.Count; i++)
            {
                var part = targets[i];
                ProgressText = "Checking " + part.Title + "  (" + (i + 1) + " of " + targets.Count + ")";

                PriceFetchResult result;
                try
                {
                    result = await _fetch.FetchAsync(part.ProductUrl);
                }
                catch (Exception ex)
                {
                    result = new PriceFetchResult { Message = "Unexpected problem: " + ex.Message };
                }

                if (result.Success)
                {
                    try
                    {
                        await _db.InsertPriceAsync(new PriceEntry
                        {
                            PartId = part.Id,
                            Shop = result.Shop,
                            Price = result.Price,
                            EntryDate = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture)
                        });
                        logged++;
                        RefreshLog.Add("Logged  ·  " + part.Title + "  —  " + Money.Format(result.Price) +
                                       " at " + result.Shop);
                    }
                    catch (Exception ex)
                    {
                        RefreshLog.Add("Skipped  ·  " + part.Title + "  —  found a price but could not save it: " + ex.Message);
                    }
                }
                else
                {
                    RefreshLog.Add("Skipped  ·  " + part.Title + "  —  " + result.Message);
                }

                ProgressValue = i + 1;

                if (i < targets.Count - 1) await Task.Delay(2000);
            }

            ProgressText = "Finished. " + logged + " of " + targets.Count + " prices logged.";
        }
        catch (Exception ex)
        {
            ProgressText = "Stopped early: " + ex.Message;
        }
        finally
        {
            IsRefreshingAll = false;
        }

        await LoadAsync();
    }

    // -------------------------------------------------------------- existing

    private void OpenEntryEditor()
    {
        if (SelectedPart == null) return;
        EntryShop = string.Empty;
        EntryPrice = string.Empty;
        EntryDate = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        EntryError = null;
        IsEntryEditorOpen = true;
    }

    private async Task SaveEntryAsync()
    {
        if (SelectedPart == null) return;

        if (!double.TryParse((EntryPrice ?? string.Empty).Trim(), NumberStyles.Any,
                CultureInfo.InvariantCulture, out var price) || price < 0)
        {
            EntryError = "Price must be a positive number, for example 76500.";
            return;
        }
        if (!DateTime.TryParseExact((EntryDate ?? string.Empty).Trim(), "yyyy-MM-dd",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
        {
            EntryError = "Date must be written as yyyy-MM-dd, for example 2026-09-19.";
            return;
        }

        try
        {
            EntryError = null;
            await _db.InsertPriceAsync(new PriceEntry
            {
                PartId = SelectedPart.Id,
                Shop = (EntryShop ?? string.Empty).Trim(),
                Price = price,
                EntryDate = EntryDate.Trim()
            });

            IsEntryEditorOpen = false;
            await LoadAsync();
        }
        catch (Exception ex)
        {
            EntryError = "Could not save the price entry: " + ex.Message;
        }
    }

    private async Task DeleteEntryAsync(PriceEntry entry)
    {
        if (entry == null) return;

        var answer = MessageBox.Show(
            "Delete the " + entry.PriceDisplay + " entry from " + entry.ShopDisplay + "?",
            "Delete price entry", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (answer != MessageBoxResult.Yes) return;

        try
        {
            await _db.DeletePriceAsync(entry.Id);
            await LoadAsync();
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not delete the entry: " + ex.Message;
        }
    }

    private async Task SaveTargetAsync()
    {
        if (SelectedPart == null) return;

        if (!double.TryParse((TargetInput ?? string.Empty).Trim(), NumberStyles.Any,
                CultureInfo.InvariantCulture, out var target) || target <= 0)
        {
            TargetError = "Target price must be a positive number.";
            return;
        }

        try
        {
            TargetError = null;
            await _db.UpdatePartTargetAsync(SelectedPart.Id, target);
            await LoadAsync();
        }
        catch (Exception ex)
        {
            TargetError = "Could not save the target: " + ex.Message;
        }
    }

    private async Task ClearTargetAsync()
    {
        if (SelectedPart == null) return;
        try
        {
            TargetError = null;
            await _db.UpdatePartTargetAsync(SelectedPart.Id, 0);
            TargetInput = string.Empty;
            await LoadAsync();
        }
        catch (Exception ex)
        {
            TargetError = "Could not clear the target: " + ex.Message;
        }
    }
}
