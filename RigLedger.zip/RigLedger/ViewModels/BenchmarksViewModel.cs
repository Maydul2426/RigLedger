using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using System.Windows;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RigLedger.Models;
using RigLedger.Services;

namespace RigLedger.ViewModels;

public partial class BenchmarksViewModel : ObservableObject, IRefreshable
{
    private readonly DatabaseService _db;
    private bool _suspendFilters;

    public ObservableCollection<BuildModel> BuildFilters { get; } = new();
    public ObservableCollection<BuildModel> Builds { get; } = new();
    public ObservableCollection<string> TestFilters { get; } = new();
    public ObservableCollection<BenchmarkRun> Runs { get; } = new();

    public ObservableCollection<string> TestPresets { get; } = new(new[]
    {
        "Cinebench R23 Multi",
        "Cinebench R23 Single",
        "3DMark Time Spy",
        "3DMark Steel Nomad",
        "Blender BMW27",
        "Game FPS (avg)",
        "Game FPS (1% low)"
    });

    [ObservableProperty] private BuildModel _selectedBuildFilter;
    [ObservableProperty] private string _selectedTestFilter;
    [ObservableProperty] private List<ChartPoint> _chartPoints = new();
    [ObservableProperty] private string _chartTitle = "Build comparison";
    [ObservableProperty] private string _chartSubtitle = "Average score per build";
    [ObservableProperty] private string _statusMessage;

    // Editor
    [ObservableProperty] private bool _isEditorOpen;
    [ObservableProperty] private BuildModel _editorBuild;
    [ObservableProperty] private string _editTestName = string.Empty;
    [ObservableProperty] private string _selectedPreset;
    [ObservableProperty] private string _editScore = string.Empty;
    [ObservableProperty] private string _editSettings = string.Empty;
    [ObservableProperty] private string _editDate = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
    [ObservableProperty] private string _editNotes = string.Empty;
    [ObservableProperty] private string _editorError;

    public IRelayCommand OpenEditorCommand { get; }
    public IRelayCommand CloseEditorCommand { get; }
    public IRelayCommand SaveRunCommand { get; }
    public IRelayCommand<BenchmarkRun> DeleteRunCommand { get; }

    public BenchmarksViewModel(DatabaseService db)
    {
        _db = db;
        OpenEditorCommand = new RelayCommand(OpenEditor);
        CloseEditorCommand = new RelayCommand(() => { IsEditorOpen = false; EditorError = null; });
        SaveRunCommand = new AsyncRelayCommand(SaveRunAsync);
        DeleteRunCommand = new AsyncRelayCommand<BenchmarkRun>(DeleteRunAsync);
    }

    public async Task LoadAsync()
    {
        try
        {
            StatusMessage = null;
            _suspendFilters = true;

            var previousBuildId = SelectedBuildFilter?.Id ?? 0;
            var previousTest = SelectedTestFilter;

            var builds = await _db.GetBuildsAsync();

            Builds.Clear();
            foreach (var b in builds) Builds.Add(b);

            BuildFilters.Clear();
            BuildFilters.Add(new BuildModel { Id = 0, Name = "All builds" });
            foreach (var b in builds) BuildFilters.Add(b);

            var names = await _db.GetTestNamesAsync();
            TestFilters.Clear();
            TestFilters.Add("All tests");
            foreach (var n in names) TestFilters.Add(n);

            SelectedBuildFilter = BuildFilters.FirstOrDefault(b => b.Id == previousBuildId) ?? BuildFilters[0];
            SelectedTestFilter = TestFilters.Contains(previousTest ?? string.Empty)
                ? previousTest
                : TestFilters[0];

            if (EditorBuild == null || Builds.All(b => b.Id != EditorBuild.Id))
            {
                EditorBuild = Builds.FirstOrDefault();
            }
            else
            {
                EditorBuild = Builds.First(b => b.Id == EditorBuild.Id);
            }

            _suspendFilters = false;
            await ApplyFilterAsync();
        }
        catch (Exception ex)
        {
            _suspendFilters = false;
            StatusMessage = "Could not load benchmarks: " + ex.Message;
        }
    }

    partial void OnSelectedBuildFilterChanged(BuildModel value)
    {
        if (_suspendFilters) return;
        _ = ApplyFilterAsync();
    }

    partial void OnSelectedTestFilterChanged(string value)
    {
        if (_suspendFilters) return;
        _ = ApplyFilterAsync();
    }

    partial void OnSelectedPresetChanged(string value)
    {
        if (!string.IsNullOrWhiteSpace(value)) EditTestName = value;
    }

    private async Task ApplyFilterAsync()
    {
        try
        {
            var buildId = SelectedBuildFilter?.Id ?? 0;
            var test = string.IsNullOrEmpty(SelectedTestFilter) || SelectedTestFilter == "All tests"
                ? string.Empty
                : SelectedTestFilter;

            var runs = await _db.GetBenchmarksAsync(buildId, test, 0);
            Runs.Clear();
            foreach (var r in runs) Runs.Add(r);

            await BuildChartAsync(test);
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not filter benchmark runs: " + ex.Message;
        }
    }

    private async Task BuildChartAsync(string test)
    {
        var all = await _db.GetBenchmarksAsync(0, string.Empty, 0);

        if (string.IsNullOrEmpty(test))
        {
            test = all.GroupBy(r => r.TestName)
                      .OrderByDescending(g => g.Count())
                      .Select(g => g.Key)
                      .FirstOrDefault() ?? string.Empty;
        }

        if (string.IsNullOrEmpty(test))
        {
            ChartTitle = "Build comparison";
            ChartSubtitle = "Log a run to unlock the comparison chart";
            ChartPoints = new List<ChartPoint>();
            return;
        }

        var points = all
            .Where(r => r.TestName == test)
            .GroupBy(r => string.IsNullOrWhiteSpace(r.BuildName) ? "Unassigned" : r.BuildName)
            .Select(g => new ChartPoint { Label = g.Key, Value = Math.Round(g.Average(r => r.Score), 2) })
            .OrderByDescending(p => p.Value)
            .ToList();

        ChartTitle = test;
        ChartSubtitle = points.Count <= 1
            ? "Average score · log the same test on another build to compare"
            : "Average score per build";
        ChartPoints = points;
    }

    private void OpenEditor()
    {
        if (Builds.Count == 0)
        {
            StatusMessage = "Create a build first — benchmark runs are always attached to a build.";
            return;
        }

        EditorBuild ??= Builds.FirstOrDefault();
        EditTestName = string.Empty;
        SelectedPreset = null;
        EditScore = string.Empty;
        EditSettings = string.Empty;
        EditDate = DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);
        EditNotes = string.Empty;
        EditorError = null;
        IsEditorOpen = true;
    }

    private async Task SaveRunAsync()
    {
        if (EditorBuild == null)
        {
            EditorError = "Pick the build this run belongs to.";
            return;
        }
        if (string.IsNullOrWhiteSpace(EditTestName))
        {
            EditorError = "Enter a test name, or pick one of the presets.";
            return;
        }
        if (!double.TryParse((EditScore ?? string.Empty).Trim(), NumberStyles.Any,
                CultureInfo.InvariantCulture, out var score))
        {
            EditorError = "Score or average FPS must be a number.";
            return;
        }
        if (!DateTime.TryParseExact((EditDate ?? string.Empty).Trim(), "yyyy-MM-dd",
                CultureInfo.InvariantCulture, DateTimeStyles.None, out _))
        {
            EditorError = "Date must be written as yyyy-MM-dd, for example 2026-09-19.";
            return;
        }

        try
        {
            EditorError = null;
            await _db.InsertBenchmarkAsync(new BenchmarkRun
            {
                BuildId = EditorBuild.Id,
                TestName = EditTestName.Trim(),
                Score = score,
                Settings = (EditSettings ?? string.Empty).Trim(),
                RunDate = EditDate.Trim(),
                Notes = (EditNotes ?? string.Empty).Trim()
            });

            IsEditorOpen = false;
            await LoadAsync();
        }
        catch (Exception ex)
        {
            EditorError = "Could not save the run: " + ex.Message;
        }
    }

    private async Task DeleteRunAsync(BenchmarkRun run)
    {
        if (run == null) return;

        var answer = MessageBox.Show(
            "Delete the " + run.TestName + " run logged on " + run.RunDate + "?",
            "Delete run", MessageBoxButton.YesNo, MessageBoxImage.Question);
        if (answer != MessageBoxResult.Yes) return;

        try
        {
            await _db.DeleteBenchmarkAsync(run.Id);
            await LoadAsync();
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not delete the run: " + ex.Message;
        }
    }
}
