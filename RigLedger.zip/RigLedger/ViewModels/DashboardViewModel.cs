﻿using System;
using System.Collections.ObjectModel;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RigLedger.Models;
using RigLedger.Services;

namespace RigLedger.ViewModels;

public partial class DashboardViewModel : ObservableObject, IRefreshable
{
    private readonly DatabaseService _db;
    private readonly ExchangeRateService _rates;

    public ObservableCollection<BuildModel> Builds { get; } = new();
    public ObservableCollection<BenchmarkRun> RecentRuns { get; } = new();
    public ObservableCollection<PriceDropItem> PriceDrops { get; } = new();

    [ObservableProperty] private string _totalBuilds = "0";
    [ObservableProperty] private string _totalParts = "0";
    [ObservableProperty] private string _totalRuns = "0";
    [ObservableProperty] private string _totalPriceEntries = "0";
    [ObservableProperty] private string _portfolioValue = "—";
    [ObservableProperty] private string _secondaryValue;
    [ObservableProperty] private bool _showSecondary;
    [ObservableProperty] private string _statusMessage;

    public IRelayCommand RefreshCommand { get; }

    public DashboardViewModel(DatabaseService db, ExchangeRateService rates)
    {
        _db = db;
        _rates = rates;
        RefreshCommand = new AsyncRelayCommand(LoadAsync);
    }

    public async Task LoadAsync()
    {
        try
        {
            StatusMessage = null;

            var builds = await _db.GetBuildsAsync();
            Builds.Clear();
            foreach (var b in builds) Builds.Add(b);

            var runs = await _db.GetBenchmarksAsync(0, string.Empty, 6);
            RecentRuns.Clear();
            foreach (var r in runs) RecentRuns.Add(r);

            var drops = await _db.GetRecentPriceDropsAsync(5);
            PriceDrops.Clear();
            foreach (var d in drops) PriceDrops.Add(d);

            TotalBuilds = builds.Count.ToString(CultureInfo.InvariantCulture);
            TotalParts = (await _db.CountPartsAsync()).ToString(CultureInfo.InvariantCulture);
            TotalRuns = (await _db.CountBenchmarksAsync()).ToString(CultureInfo.InvariantCulture);
            TotalPriceEntries = (await _db.CountPricesAsync()).ToString(CultureInfo.InvariantCulture);

            var total = builds.Sum(b => b.TotalCost);
            PortfolioValue = Money.Format(total);

            await UpdateSecondaryAsync(total);
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not load the dashboard: " + ex.Message;
        }
    }

    private async Task UpdateSecondaryAsync(double total)
    {
        try
        {
            var baseCode = ExchangeRateService.Normalize(await _db.GetSettingAsync("BaseCurrencyCode", "BDT"));
            var target = ExchangeRateService.Normalize(await _db.GetSettingAsync("SecondaryCurrencyCode", "USD"));

            if (target.Length < 3 || baseCode.Length < 3 || baseCode == target)
            {
                ShowSecondary = false;
                SecondaryValue = null;
                return;
            }

            ShowSecondary = true;

            var rate = await _rates.GetRateAsync(baseCode, target);

            if (rate.HasValue && rate.Value > 0)
            {
                var converted = total * rate.Value;
                SecondaryValue = "\u2248 " + converted.ToString("#,##0.##", CultureInfo.InvariantCulture) +
                                 " " + target + "  ·  " + await _rates.GetLastUpdatedAsync();
            }
            else
            {
                SecondaryValue = "Approximate " + target + " value unavailable — no cached exchange rate yet. " +
                                 "Update rates on the Settings page while online.";
            }
        }
        catch (Exception ex)
        {
            ShowSecondary = true;
            SecondaryValue = "Could not work out the second currency: " + ex.Message;
        }
    }
}
