﻿using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using RigLedger.Services;

namespace RigLedger.ViewModels;

public partial class MainViewModel : ObservableObject
{
    public DashboardViewModel Dashboard { get; }
    public BuildsViewModel Builds { get; }
    public BenchmarksViewModel Benchmarks { get; }
    public PricesViewModel Prices { get; }
    public AssistantViewModel Assistant { get; }
    public SettingsViewModel SettingsPage { get; }

    public ConnectivityService Connectivity { get; }

    public ObservableCollection<NavItem> NavItems { get; } = new();

    [ObservableProperty] private NavItem _selectedNavItem;
    [ObservableProperty] private object _currentViewModel;

    public MainViewModel(DatabaseService db, ThemeService theme, bool isDark,
        ConnectivityService connectivity, ExchangeRateService rates,
        PriceFetchService priceFetch, GeminiService gemini)
    {
        Connectivity = connectivity;

        Dashboard = new DashboardViewModel(db, rates);
        Builds = new BuildsViewModel(db);
        Benchmarks = new BenchmarksViewModel(db);
        Prices = new PricesViewModel(db, priceFetch);
        Assistant = new AssistantViewModel(db, gemini);
        SettingsPage = new SettingsViewModel(db, theme, isDark, RefreshAllAsync, gemini, rates);

        NavItems.Add(new NavItem("\uE80F", "Dashboard", Dashboard));
        NavItems.Add(new NavItem("\uE8F1", "Build planner", Builds));
        NavItems.Add(new NavItem("\uE9D2", "Benchmarks", Benchmarks));
        NavItems.Add(new NavItem("\uE8C7", "Price tracker", Prices));
        NavItems.Add(new NavItem("\uE8BD", "AI assistant", Assistant));
        NavItems.Add(new NavItem("\uE713", "Settings", SettingsPage));

        SelectedNavItem = NavItems[0];
    }

    partial void OnSelectedNavItemChanged(NavItem value)
    {
        CurrentViewModel = value?.ViewModel;
        _ = RefreshCurrentAsync();
    }

    public async Task LoadAsync()
    {
        await RefreshCurrentAsync();
    }

    private async Task RefreshCurrentAsync()
    {
        if (CurrentViewModel is IRefreshable refreshable)
        {
            await refreshable.LoadAsync();
        }
    }

    public async Task RefreshAllAsync()
    {
        await Dashboard.LoadAsync();
        await Builds.LoadAsync();
        await Benchmarks.LoadAsync();
        await Prices.LoadAsync();
    }
}
