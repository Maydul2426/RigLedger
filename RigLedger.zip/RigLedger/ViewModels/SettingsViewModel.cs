﻿using System;
using System.Collections.ObjectModel;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RigLedger.Services;

namespace RigLedger.ViewModels;

public partial class SettingsViewModel : ObservableObject, IRefreshable
{
    private readonly DatabaseService _db;
    private readonly ThemeService _theme;
    private readonly Func<Task> _refreshAll;
    private readonly GeminiService _gemini;
    private readonly ExchangeRateService _rates;
    private bool _suspend;

    public ObservableCollection<string> CurrencyPresets { get; } = new(new[]
    {
        "\u09F3", "$", "\u20AC", "\u00A3", "\u20B9", "\u00A5"
    });

    [ObservableProperty] private bool _isDarkTheme;
    [ObservableProperty] private string _currencySymbol;
    [ObservableProperty] private string _currencyError;
    [ObservableProperty] private string _savedMessage;
    [ObservableProperty] private string _statusMessage;

    // Exchange rates
    [ObservableProperty] private string _baseCurrencyCode = "BDT";
    [ObservableProperty] private string _secondaryCurrencyCode = "USD";
    [ObservableProperty] private string _ratesMessage;
    [ObservableProperty] private bool _isUpdatingRates;

    // AI assistant
    [ObservableProperty] private string _apiKey = string.Empty;
    [ObservableProperty] private string _modelName = GeminiService.DefaultModel;
    [ObservableProperty] private string _aiMessage;
    [ObservableProperty] private bool _isTesting;

    public bool IsNotTesting => !IsTesting;

    public string DatabasePath { get; }
    public string PreviewLine => "Sample total · " + Money.Format(124500);

    public IRelayCommand SaveCurrencyCommand { get; }
    public IRelayCommand<string> UsePresetCommand { get; }
    public IRelayCommand SaveCurrencyCodesCommand { get; }
    public IRelayCommand UpdateRatesCommand { get; }
    public IRelayCommand SaveAiCommand { get; }
    public IRelayCommand TestConnectionCommand { get; }
    public IRelayCommand ClearApiKeyCommand { get; }

    public SettingsViewModel(DatabaseService db, ThemeService theme, bool isDark, Func<Task> refreshAll,
        GeminiService gemini, ExchangeRateService rates)
    {
        _db = db;
        _theme = theme;
        _refreshAll = refreshAll;
        _gemini = gemini;
        _rates = rates;

        DatabasePath = db.DatabasePath;

        _suspend = true;
        IsDarkTheme = isDark;
        CurrencySymbol = Money.Symbol;
        _suspend = false;

        SaveCurrencyCommand = new AsyncRelayCommand(SaveCurrencyAsync);
        UsePresetCommand = new AsyncRelayCommand<string>(UsePresetAsync);
        SaveCurrencyCodesCommand = new AsyncRelayCommand(SaveCurrencyCodesAsync);
        UpdateRatesCommand = new AsyncRelayCommand(UpdateRatesAsync);
        SaveAiCommand = new AsyncRelayCommand(SaveAiAsync);
        TestConnectionCommand = new AsyncRelayCommand(TestConnectionAsync);
        ClearApiKeyCommand = new AsyncRelayCommand(ClearApiKeyAsync);
    }

    partial void OnIsTestingChanged(bool value) => OnPropertyChanged(nameof(IsNotTesting));

    public async Task LoadAsync()
    {
        try
        {
            StatusMessage = null;
            _suspend = true;

            CurrencySymbol = Money.Symbol;
            BaseCurrencyCode = await _db.GetSettingAsync("BaseCurrencyCode", "BDT");
            SecondaryCurrencyCode = await _db.GetSettingAsync("SecondaryCurrencyCode", "USD");
            ApiKey = await _db.GetSettingAsync("GeminiApiKey", string.Empty);
            ModelName = await _db.GetSettingAsync("GeminiModel", GeminiService.DefaultModel);

            if (string.IsNullOrWhiteSpace(ModelName)) ModelName = GeminiService.DefaultModel;

            _suspend = false;

            RatesMessage = await _rates.GetLastUpdatedAsync();
        }
        catch (Exception ex)
        {
            _suspend = false;
            StatusMessage = "Could not read the saved settings: " + ex.Message;
        }
    }

    partial void OnIsDarkThemeChanged(bool value)
    {
        if (_suspend) return;
        _ = ApplyThemeAsync(value);
    }

    private async Task ApplyThemeAsync(bool dark)
    {
        try
        {
            StatusMessage = null;
            _theme.Apply(dark);
            await _db.SetSettingAsync("Theme", dark ? "Dark" : "Light");
            SavedMessage = dark ? "Soft dark theme applied and saved." : "Light pastel theme applied and saved.";
        }
        catch (Exception ex)
        {
            StatusMessage = "Theme changed, but could not be saved: " + ex.Message;
        }
    }

    private async Task UsePresetAsync(string symbol)
    {
        if (string.IsNullOrWhiteSpace(symbol)) return;
        CurrencySymbol = symbol;
        await SaveCurrencyAsync();
    }

    private async Task SaveCurrencyAsync()
    {
        var symbol = (CurrencySymbol ?? string.Empty).Trim();

        if (string.IsNullOrEmpty(symbol))
        {
            CurrencyError = "Enter a currency symbol, for example \u09F3 or $.";
            return;
        }
        if (symbol.Length > 4)
        {
            CurrencyError = "Keep the symbol to four characters or fewer.";
            return;
        }

        try
        {
            CurrencyError = null;
            Money.Symbol = symbol;
            await _db.SetSettingAsync("Currency", symbol);
            OnPropertyChanged(nameof(PreviewLine));
            SavedMessage = "Currency saved. Every price now shows as " + Money.Format(1250) + ".";

            if (_refreshAll != null) await _refreshAll();
        }
        catch (Exception ex)
        {
            CurrencyError = "Could not save the currency: " + ex.Message;
        }
    }

    // ------------------------------------------------------------ exchange rates

    private async Task SaveCurrencyCodesAsync()
    {
        var baseCode = ExchangeRateService.Normalize(BaseCurrencyCode);
        var target = ExchangeRateService.Normalize(SecondaryCurrencyCode);

        if (baseCode.Length < 3)
        {
            RatesMessage = "The main currency needs a three letter code, for example BDT.";
            return;
        }

        try
        {
            BaseCurrencyCode = baseCode;
            SecondaryCurrencyCode = target;

            await _db.SetSettingAsync("BaseCurrencyCode", baseCode);
            await _db.SetSettingAsync("SecondaryCurrencyCode", target);

            RatesMessage = target.Length < 3
                ? "Saved. No second currency set, so the dashboard shows one total only."
                : "Saved. The dashboard will show an approximate " + target + " total.";

            if (_refreshAll != null) await _refreshAll();
        }
        catch (Exception ex)
        {
            RatesMessage = "Could not save the currency codes: " + ex.Message;
        }
    }

    private async Task UpdateRatesAsync()
    {
        if (IsUpdatingRates) return;

        IsUpdatingRates = true;
        RatesMessage = "Fetching the latest rates…";

        try
        {
            var baseCode = ExchangeRateService.Normalize(BaseCurrencyCode);
            await _db.SetSettingAsync("BaseCurrencyCode", baseCode);

            var result = await _rates.RefreshAsync(baseCode);
            RatesMessage = result.Message;

            if (result.Success && _refreshAll != null) await _refreshAll();
        }
        catch (Exception ex)
        {
            RatesMessage = "Could not update rates: " + ex.Message;
        }
        finally
        {
            IsUpdatingRates = false;
        }
    }

    // ------------------------------------------------------------ AI assistant

    private async Task SaveAiAsync()
    {
        try
        {
            var model = (ModelName ?? string.Empty).Trim();
            if (model.Length == 0)
            {
                model = GeminiService.DefaultModel;
                ModelName = model;
            }

            await _db.SetSettingAsync("GeminiApiKey", (ApiKey ?? string.Empty).Trim());
            await _db.SetSettingAsync("GeminiModel", model);

            AiMessage = string.IsNullOrWhiteSpace(ApiKey)
                ? "Key cleared. The assistant will ask for one."
                : "Saved to your local database only. It is never sent anywhere except Google's API.";
        }
        catch (Exception ex)
        {
            AiMessage = "Could not save the AI settings: " + ex.Message;
        }
    }

    private async Task ClearApiKeyAsync()
    {
        ApiKey = string.Empty;
        await SaveAiAsync();
    }

    private async Task TestConnectionAsync()
    {
        if (IsTesting) return;

        if (string.IsNullOrWhiteSpace(ApiKey))
        {
            AiMessage = "Enter an API key first, then press Save.";
            return;
        }

        IsTesting = true;
        AiMessage = "Testing…";

        try
        {
            await SaveAiAsync();

            var result = await _gemini.TestAsync(ApiKey, ModelName);

            AiMessage = result.Success
                ? "Connection works. Model replied: " + result.Text
                : result.Message;
        }
        catch (Exception ex)
        {
            AiMessage = "Test failed: " + ex.Message;
        }
        finally
        {
            IsTesting = false;
        }
    }
}
