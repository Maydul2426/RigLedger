﻿using System;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CommunityToolkit.Mvvm.ComponentModel;
using CommunityToolkit.Mvvm.Input;
using RigLedger.Models;
using RigLedger.Services;

namespace RigLedger.ViewModels;

public partial class AssistantViewModel : ObservableObject, IRefreshable
{
    private const int MaxContextChars = 6000;

    private readonly DatabaseService _db;
    private readonly GeminiService _gemini;

    private string _apiKey = string.Empty;
    private string _modelName = GeminiService.DefaultModel;

    public ObservableCollection<ChatMessage> Messages { get; } = new();

    [ObservableProperty] private string _inputText = string.Empty;
    [ObservableProperty] private bool _isBusy;
    [ObservableProperty] private string _statusMessage;
    [ObservableProperty] private string _modelLabel = "Not configured";

    public bool CanSend => !IsBusy;

    public IRelayCommand SendCommand { get; }
    public IRelayCommand ClearCommand { get; }

    public AssistantViewModel(DatabaseService db, GeminiService gemini)
    {
        _db = db;
        _gemini = gemini;

        SendCommand = new AsyncRelayCommand(SendAsync);
        ClearCommand = new RelayCommand(ClearChat);
    }

    partial void OnIsBusyChanged(bool value) => OnPropertyChanged(nameof(CanSend));

    public async Task LoadAsync()
    {
        try
        {
            _apiKey = await _db.GetSettingAsync("GeminiApiKey", string.Empty);
            _modelName = await _db.GetSettingAsync("GeminiModel", GeminiService.DefaultModel);

            if (string.IsNullOrWhiteSpace(_modelName)) _modelName = GeminiService.DefaultModel;

            if (string.IsNullOrWhiteSpace(_apiKey))
            {
                ModelLabel = "No API key saved";
                StatusMessage = "Add a Gemini API key on the Settings page to use the assistant. " +
                                "Everything else in RigLedger works without one.";
            }
            else
            {
                ModelLabel = "Model: " + _modelName;
                if (Messages.Count == 0)
                    StatusMessage = "Ask about your builds, parts or prices. The assistant sees a summary of your data.";
                else
                    StatusMessage = null;
            }
        }
        catch (Exception ex)
        {
            StatusMessage = "Could not read the assistant settings: " + ex.Message;
        }
    }

    private void ClearChat()
    {
        Messages.Clear();
        StatusMessage = "Conversation cleared. Nothing was ever saved to disk.";
    }

    private async Task SendAsync()
    {
        if (IsBusy) return;

        var question = (InputText ?? string.Empty).Trim();
        if (question.Length == 0) return;

        if (string.IsNullOrWhiteSpace(_apiKey))
        {
            StatusMessage = "No Gemini API key saved yet. Add one on the Settings page.";
            return;
        }

        Messages.Add(new ChatMessage { IsUser = true, Text = question });
        InputText = string.Empty;
        StatusMessage = "Thinking…";
        IsBusy = true;

        try
        {
            var context = await BuildContextAsync();
            var history = Messages.ToList();

            var reply = await _gemini.SendAsync(_apiKey, _modelName, context, history);

            if (reply.Success)
            {
                Messages.Add(new ChatMessage { IsUser = false, Text = reply.Text });
                StatusMessage = null;
            }
            else
            {
                StatusMessage = reply.Message;
            }
        }
        catch (Exception ex)
        {
            StatusMessage = "Something went wrong: " + ex.Message;
        }
        finally
        {
            IsBusy = false;
        }
    }

    private static string Shorten(string text, int max)
    {
        if (string.IsNullOrWhiteSpace(text)) return "none";
        text = text.Replace("\r", " ").Replace("\n", " ").Trim();
        return text.Length <= max ? text : text.Substring(0, max) + "…";
    }

    private async Task<string> BuildContextAsync()
    {
        var sb = new StringBuilder();

        sb.AppendLine("You are the assistant built into RigLedger, an offline PC build planner used by a PC hardware reviewer.");
        sb.AppendLine("Answer only from the data below. Money amounts are shown in " + Money.Symbol + ".");
        sb.AppendLine("If the data does not cover the question, say so plainly instead of guessing.");
        sb.AppendLine("Keep answers short, concrete and specific. Use plain text, no markdown tables.");
        sb.AppendLine();

        try
        {
            var builds = await _db.GetBuildsAsync();
            sb.AppendLine("BUILDS:");
            if (builds.Count == 0) sb.AppendLine("- none yet");
            foreach (var b in builds)
            {
                sb.AppendLine("- " + b.Name +
                              " | total " + b.TotalCostDisplay +
                              " | " + b.PartCount + " parts" +
                              " | est. draw " + b.EstimatedWatts + "W" +
                              " | PSU " + b.PsuWatts + "W" +
                              " | notes: " + Shorten(b.Notes, 110));
            }

            var parts = await _db.GetAllPartsAsync();
            sb.AppendLine();
            sb.AppendLine("PARTS:");
            if (parts.Count == 0) sb.AppendLine("- none yet");
            foreach (var p in parts)
            {
                if (sb.Length > 5200) { sb.AppendLine("- (list truncated)"); break; }
                sb.AppendLine("- [" + (string.IsNullOrWhiteSpace(p.BuildName) ? "Unassigned" : p.BuildName) + "] " +
                              p.PartType + ": " + p.Title +
                              " | listed " + p.PriceDisplay +
                              " | latest " + p.LatestDisplay +
                              " | lowest " + p.LowestDisplay +
                              " | target " + p.TargetDisplay +
                              " | " + p.SpecSummary);
            }

            var runs = await _db.GetBenchmarksAsync(0, string.Empty, 12);
            sb.AppendLine();
            sb.AppendLine("RECENT BENCHMARK RUNS:");
            if (runs.Count == 0) sb.AppendLine("- none yet");
            foreach (var r in runs)
            {
                if (sb.Length > 5800) { sb.AppendLine("- (list truncated)"); break; }
                sb.AppendLine("- " + r.BuildName + " | " + r.TestName + " | " + r.ScoreDisplay +
                              " | " + Shorten(r.Settings, 40) + " | " + r.RunDate);
            }
        }
        catch (Exception ex)
        {
            sb.AppendLine("(Some data could not be read: " + ex.Message + ")");
        }

        var context = sb.ToString();
        return context.Length > MaxContextChars ? context.Substring(0, MaxContextChars) : context;
    }
}
