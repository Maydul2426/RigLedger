using System.Threading.Tasks;

namespace RigLedger.ViewModels;

public interface IRefreshable
{
    Task LoadAsync();
}
