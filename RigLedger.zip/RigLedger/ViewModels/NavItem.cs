namespace RigLedger.ViewModels;

public class NavItem
{
    public NavItem(string glyph, string title, object viewModel)
    {
        Glyph = glyph;
        Title = title;
        ViewModel = viewModel;
    }

    public string Glyph { get; }
    public string Title { get; }
    public object ViewModel { get; }

    public override string ToString() => Title;
}
