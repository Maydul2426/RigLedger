using System.Windows.Media;

namespace RigLedger.Models;

public class ChartPoint
{
    public string Label { get; set; } = "";
    public double Value { get; set; }
    public Brush Fill { get; set; }
}
