﻿using System;
using System.Globalization;

namespace RigLedger.Models;

public class ChatMessage
{
    public bool IsUser { get; set; }
    public string Text { get; set; } = "";
    public string Sent { get; set; } = DateTime.Now.ToString("HH:mm", CultureInfo.InvariantCulture);

    public string RoleLabel => IsUser ? "You" : "Assistant";
}
