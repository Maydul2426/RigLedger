namespace RigLedger.Models;

public static class PartCatalog
{
    public static readonly string[] Types =
    {
        "CPU", "Motherboard", "RAM", "GPU", "Storage", "PSU", "Case", "Cooler"
    };

    public static string ShortCode(string type) => type switch
    {
        "CPU" => "CPU",
        "Motherboard" => "MB",
        "RAM" => "RAM",
        "GPU" => "GPU",
        "Storage" => "SSD",
        "PSU" => "PSU",
        "Case" => "CSE",
        "Cooler" => "FAN",
        _ => "PRT"
    };

    public static string SpecALabel(string type) => type switch
    {
        "CPU" => "Socket",
        "Motherboard" => "Socket",
        "RAM" => "Memory type",
        "GPU" => "Interface",
        "Storage" => "Interface",
        "PSU" => "Standard",
        "Case" => "Form factor",
        "Cooler" => "Socket support",
        _ => "Spec A"
    };

    public static string SpecBLabel(string type) => type switch
    {
        "CPU" => "Cores / threads",
        "Motherboard" => "Form factor",
        "RAM" => "Capacity / speed",
        "GPU" => "VRAM",
        "Storage" => "Capacity",
        "PSU" => "Efficiency rating",
        "Case" => "Included fans",
        "Cooler" => "Cooler type",
        _ => "Spec B"
    };

    public static string WattsLabel(string type) => type switch
    {
        "PSU" => "PSU wattage (W)",
        "CPU" => "TDP (W)",
        "GPU" => "TDP (W)",
        _ => "Power draw (W)"
    };

    public static string WattsHint(string type) => type == "PSU"
        ? "Rated output. Excluded from estimated draw, used for headroom."
        : "Counted towards the build's estimated power draw.";
}
