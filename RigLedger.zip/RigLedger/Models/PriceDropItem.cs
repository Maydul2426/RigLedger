using System.Globalization;
using RigLedger.Services;

namespace RigLedger.Models;

public class PriceDropItem
{
    public string PartTitle { get; set; } = "";
    public string BuildName { get; set; } = "";
    public string Shop { get; set; } = "";
    public string EntryDate { get; set; } = "";
    public double OldPrice { get; set; }
    public double NewPrice { get; set; }

    public double Drop => OldPrice - NewPrice;
    public string DropDisplay => "-" + Money.Format(Drop);
    public string PercentDisplay => OldPrice <= 0
        ? ""
        : "-" + (Drop / OldPrice * 100.0).ToString("0.#", CultureInfo.InvariantCulture) + "%";
    public string FromToDisplay => Money.Format(OldPrice) + "  →  " + Money.Format(NewPrice);
    public string SubLine => BuildName + "  ·  " + Shop + "  ·  " + EntryDate;
}
