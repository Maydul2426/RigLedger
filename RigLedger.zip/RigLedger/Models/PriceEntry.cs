using RigLedger.Services;

namespace RigLedger.Models;

public class PriceEntry
{
    public int Id { get; set; }
    public int PartId { get; set; }
    public string Shop { get; set; } = "";
    public double Price { get; set; }
    public string EntryDate { get; set; } = "";

    public string PriceDisplay => Money.Format(Price);
    public string ShopDisplay => string.IsNullOrWhiteSpace(Shop) ? "Unknown shop" : Shop;
}
