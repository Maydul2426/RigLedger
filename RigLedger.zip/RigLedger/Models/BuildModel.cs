using RigLedger.Services;

namespace RigLedger.Models;

public class BuildModel
{
    public int Id { get; set; }
    public string Name { get; set; } = "";
    public string Notes { get; set; } = "";
    public string CreatedUtc { get; set; } = "";

    // Aggregates filled by DatabaseService, not persisted.
    public int PartCount { get; set; }
    public double TotalCost { get; set; }
    public int EstimatedWatts { get; set; }
    public int PsuWatts { get; set; }

    public string TotalCostDisplay => Money.Format(TotalCost);
    public string PowerDisplay => EstimatedWatts + " W";
    public string PartCountDisplay => PartCount + (PartCount == 1 ? " part" : " parts");

    public string SummaryLine => PartCountDisplay + "  ·  " + PowerDisplay;

    public string HeadroomDisplay
    {
        get
        {
            if (PsuWatts <= 0) return "No PSU added";
            var headroom = PsuWatts - EstimatedWatts;
            if (headroom < 0) return PsuWatts + " W PSU · over by " + (-headroom) + " W";
            return PsuWatts + " W PSU · " + headroom + " W headroom";
        }
    }

    public override string ToString() => Name;
}
