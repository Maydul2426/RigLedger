using System.Globalization;

namespace RigLedger.Models;

public class BenchmarkRun
{
    public int Id { get; set; }
    public int BuildId { get; set; }
    public string TestName { get; set; } = "";
    public double Score { get; set; }
    public string Settings { get; set; } = "";
    public string RunDate { get; set; } = "";
    public string Notes { get; set; } = "";

    // Not persisted.
    public string BuildName { get; set; } = "";

    public string ScoreDisplay => Score.ToString("#,##0.##", CultureInfo.InvariantCulture);
    public string SettingsDisplay => string.IsNullOrWhiteSpace(Settings) ? "—" : Settings;
    public string NotesDisplay => string.IsNullOrWhiteSpace(Notes) ? "—" : Notes;
    public string HeadLine => TestName + "  ·  " + ScoreDisplay;
    public string SubLine => BuildName + "  ·  " + RunDate;
}
