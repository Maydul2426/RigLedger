﻿using System.Collections.Generic;
using RigLedger.Services;

namespace RigLedger.Models;

public class PartModel
{
    public int Id { get; set; }
    public int BuildId { get; set; }
    public string PartType { get; set; } = "CPU";
    public string Brand { get; set; } = "";
    public string Model { get; set; } = "";
    public double Price { get; set; }
    public string SpecA { get; set; } = "";
    public string SpecB { get; set; } = "";
    public int Watts { get; set; }
    public double TargetPrice { get; set; }
    public string ProductUrl { get; set; } = "";

    // Not persisted.
    public string BuildName { get; set; } = "";
    public double LatestPrice { get; set; }
    public double LowestPrice { get; set; }
    public int PriceEntryCount { get; set; }

    public string Title
    {
        get
        {
            var t = (Brand + " " + Model).Trim();
            return string.IsNullOrWhiteSpace(t) ? "(unnamed part)" : t;
        }
    }

    public string ShortCode => PartCatalog.ShortCode(PartType);

    public string PriceDisplay => Money.Format(Price);

    public string SpecSummary
    {
        get
        {
            var bits = new List<string>();
            if (!string.IsNullOrWhiteSpace(SpecA)) bits.Add(SpecA);
            if (!string.IsNullOrWhiteSpace(SpecB)) bits.Add(SpecB);
            if (Watts > 0) bits.Add(Watts + " W");
            return bits.Count == 0 ? "No specs recorded" : string.Join("  ·  ", bits);
        }
    }

    public bool HasTarget => TargetPrice > 0;
    public string TargetDisplay => HasTarget ? Money.Format(TargetPrice) : "Not set";
    public string LatestDisplay => LatestPrice > 0 ? Money.Format(LatestPrice) : "—";
    public string LowestDisplay => LowestPrice > 0 ? Money.Format(LowestPrice) : "—";
    public string EntryCountDisplay => PriceEntryCount + (PriceEntryCount == 1 ? " entry" : " entries");
    public bool TargetHit => HasTarget && LatestPrice > 0 && LatestPrice <= TargetPrice;
    public string TargetBadge => TargetHit ? "At target" : "Above target";

    public bool HasUrl => !string.IsNullOrWhiteSpace(ProductUrl);

    public string ListSubtitle
    {
        get
        {
            var b = string.IsNullOrWhiteSpace(BuildName) ? "Unassigned" : BuildName;
            return b + "  ·  " + (LatestPrice > 0 ? LatestDisplay : PriceDisplay);
        }
    }

    public override string ToString() => Title;
}
