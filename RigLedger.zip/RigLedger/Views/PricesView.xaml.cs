using System.Windows.Controls;

namespace RigLedger.Views;

public partial class PricesView : UserControl
{
    public PricesView()
    {
        InitializeComponent();
    }
}
