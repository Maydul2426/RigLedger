﻿using System.Windows;
using System.Windows.Controls;
using RigLedger.ViewModels;

namespace RigLedger.Views;

public partial class SettingsView : UserControl
{
    private bool _syncing;

    public SettingsView()
    {
        InitializeComponent();
        Loaded += (_, _) => PullKeyFromViewModel();
        DataContextChanged += (_, _) => PullKeyFromViewModel();
    }

    /// <summary>
    /// PasswordBox.Password cannot be data bound, so it is synced by hand.
    /// </summary>
    private void PullKeyFromViewModel()
    {
        if (ApiKeyBox == null) return;
        if (DataContext is not SettingsViewModel vm) return;

        var key = vm.ApiKey ?? string.Empty;
        if (ApiKeyBox.Password == key) return;

        _syncing = true;
        ApiKeyBox.Password = key;
        _syncing = false;
    }

    private void ApiKeyBox_PasswordChanged(object sender, RoutedEventArgs e)
    {
        if (_syncing) return;
        if (DataContext is SettingsViewModel vm) vm.ApiKey = ApiKeyBox.Password;
    }
}
