using System.Windows.Controls;

namespace RigLedger.Views;

public partial class BenchmarksView : UserControl
{
    public BenchmarksView()
    {
        InitializeComponent();
    }
}
