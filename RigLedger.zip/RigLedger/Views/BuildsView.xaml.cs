using System.Windows.Controls;

namespace RigLedger.Views;

public partial class BuildsView : UserControl
{
    public BuildsView()
    {
        InitializeComponent();
    }
}
