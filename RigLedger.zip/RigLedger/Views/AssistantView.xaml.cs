﻿using System.Collections.Specialized;
using System.Windows;
using System.Windows.Controls;
using RigLedger.ViewModels;

namespace RigLedger.Views;

public partial class AssistantView : UserControl
{
    public AssistantView()
    {
        InitializeComponent();
        DataContextChanged += OnDataContextChanged;
    }

    private void OnDataContextChanged(object sender, DependencyPropertyChangedEventArgs e)
    {
        if (e.OldValue is AssistantViewModel previous)
            previous.Messages.CollectionChanged -= OnMessagesChanged;

        if (e.NewValue is AssistantViewModel current)
            current.Messages.CollectionChanged += OnMessagesChanged;
    }

    private void OnMessagesChanged(object sender, NotifyCollectionChangedEventArgs e)
    {
        ChatScroll?.ScrollToEnd();
    }
}
