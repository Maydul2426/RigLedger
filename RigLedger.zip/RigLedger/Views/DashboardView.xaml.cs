using System.Windows.Controls;

namespace RigLedger.Views;

public partial class DashboardView : UserControl
{
    public DashboardView()
    {
        InitializeComponent();
    }
}
