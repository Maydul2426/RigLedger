using System;
using System.Windows;

namespace RigLedger.Services;

public class ThemeService
{
    private const string LightUri = "pack://application:,,,/RigLedger;component/Resources/Theme.Light.xaml";
    private const string DarkUri = "pack://application:,,,/RigLedger;component/Resources/Theme.Dark.xaml";

    public bool IsDark { get; private set; }

    public void Apply(bool dark)
    {
        IsDark = dark;

        var app = Application.Current;
        if (app == null) return;

        var dict = new ResourceDictionary { Source = new Uri(dark ? DarkUri : LightUri, UriKind.Absolute) };
        var merged = app.Resources.MergedDictionaries;

        for (var i = 0; i < merged.Count; i++)
        {
            var source = merged[i].Source?.OriginalString ?? string.Empty;
            if (source.Contains("Theme.", StringComparison.OrdinalIgnoreCase))
            {
                merged[i] = dict;
                return;
            }
        }

        merged.Insert(0, dict);
    }
}
