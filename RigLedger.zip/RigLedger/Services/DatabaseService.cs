﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Data.Sqlite;
using RigLedger.Models;

namespace RigLedger.Services;

public class PriceStat
{
    public double Latest { get; set; }
    public double Lowest { get; set; }
    public int Count { get; set; }
    public double Previous { get; set; }
    public string LatestShop { get; set; } = "";
    public string LatestDate { get; set; } = "";
}

public class DatabaseService
{
    private readonly string _connectionString;

    public string DatabasePath { get; }
    public string DatabaseFolder { get; }

    public DatabaseService()
    {
        DatabaseFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), "RigLedger");
        Directory.CreateDirectory(DatabaseFolder);
        DatabasePath = Path.Combine(DatabaseFolder, "rigledger.db");
        _connectionString = new SqliteConnectionStringBuilder { DataSource = DatabasePath }.ToString();
    }

    private async Task<SqliteConnection> OpenAsync()
    {
        var connection = new SqliteConnection(_connectionString);
        await connection.OpenAsync();
        return connection;
    }

    private static string S(DbDataReader r, int i) => r.IsDBNull(i) ? string.Empty : r.GetString(i);
    private static double D(DbDataReader r, int i) => r.IsDBNull(i) ? 0d : r.GetDouble(i);
    private static int I(DbDataReader r, int i) => r.IsDBNull(i) ? 0 : r.GetInt32(i);

    // ---------------------------------------------------------------- schema

    public async Task InitializeAsync()
    {
        using var connection = await OpenAsync();

        using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText = @"
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS Builds (
    Id         INTEGER PRIMARY KEY AUTOINCREMENT,
    Name       TEXT NOT NULL,
    Notes      TEXT,
    CreatedUtc TEXT
);

CREATE TABLE IF NOT EXISTS Parts (
    Id          INTEGER PRIMARY KEY AUTOINCREMENT,
    BuildId     INTEGER NOT NULL,
    PartType    TEXT NOT NULL,
    Brand       TEXT,
    Model       TEXT,
    Price       REAL NOT NULL DEFAULT 0,
    SpecA       TEXT,
    SpecB       TEXT,
    Watts       INTEGER NOT NULL DEFAULT 0,
    TargetPrice REAL NOT NULL DEFAULT 0
);

CREATE TABLE IF NOT EXISTS Benchmarks (
    Id       INTEGER PRIMARY KEY AUTOINCREMENT,
    BuildId  INTEGER NOT NULL,
    TestName TEXT NOT NULL,
    Score    REAL NOT NULL DEFAULT 0,
    Settings TEXT,
    RunDate  TEXT,
    Notes    TEXT
);

CREATE TABLE IF NOT EXISTS Prices (
    Id        INTEGER PRIMARY KEY AUTOINCREMENT,
    PartId    INTEGER NOT NULL,
    Shop      TEXT,
    Price     REAL NOT NULL DEFAULT 0,
    EntryDate TEXT
);

CREATE TABLE IF NOT EXISTS Settings (
    SettingKey   TEXT PRIMARY KEY,
    SettingValue TEXT
);

CREATE INDEX IF NOT EXISTS IX_Parts_Build ON Parts (BuildId);
CREATE INDEX IF NOT EXISTS IX_Bench_Build ON Benchmarks (BuildId);
CREATE INDEX IF NOT EXISTS IX_Prices_Part ON Prices (PartId);";
            await cmd.ExecuteNonQueryAsync();
        }

        // Added in 1.1. Safe on databases created by 1.0.
        await EnsureColumnAsync(connection, "Parts", "ProductUrl", "TEXT");

        await SeedIfNeededAsync(connection);
    }

    /// <summary>Adds a column only when PRAGMA table_info shows it is missing.</summary>
    private static async Task EnsureColumnAsync(SqliteConnection connection, string table, string column, string type)
    {
        var exists = false;

        using (var check = connection.CreateCommand())
        {
            check.CommandText = "PRAGMA table_info(" + table + ")";
            using var r = await check.ExecuteReaderAsync();
            while (await r.ReadAsync())
            {
                var name = S(r, 1);
                if (string.Equals(name, column, StringComparison.OrdinalIgnoreCase))
                {
                    exists = true;
                    break;
                }
            }
        }

        if (exists) return;

        using var alter = connection.CreateCommand();
        alter.CommandText = "ALTER TABLE " + table + " ADD COLUMN " + column + " " + type;
        await alter.ExecuteNonQueryAsync();
    }

    private static async Task SeedIfNeededAsync(SqliteConnection connection)
    {
        using (var check = connection.CreateCommand())
        {
            check.CommandText = "SELECT COUNT(*) FROM Settings WHERE SettingKey='Seeded'";
            var seeded = System.Convert.ToInt32(await check.ExecuteScalarAsync(), CultureInfo.InvariantCulture);
            if (seeded > 0) return;
        }

        string Day(int daysAgo) => DateTime.Today.AddDays(-daysAgo).ToString("yyyy-MM-dd", CultureInfo.InvariantCulture);

        var sql = $@"
INSERT INTO Builds (Name, Notes, CreatedUtc) VALUES
 ('Creator Rig 2025', 'Editing, rendering and colour work. Quiet under sustained load.', '{Day(140)}'),
 ('Esports Value Build', '1080p high refresh. Budget first, upgrade path second.', '{Day(62)}');

INSERT INTO Parts (BuildId, PartType, Brand, Model, Price, SpecA, SpecB, Watts, TargetPrice) VALUES
 (1, 'CPU',         'AMD',         'Ryzen 7 7700X',             42000, 'AM5',          '8C / 16T',        105, 40000),
 (1, 'Motherboard', 'MSI',         'B650 Tomahawk WiFi',        27000, 'AM5',          'ATX',              12, 0),
 (1, 'RAM',         'G.Skill',     'Flare X5 32GB (2x16) 6000', 14500, 'DDR5',         '32 GB / 6000 MT/s', 10, 0),
 (1, 'GPU',         'NVIDIA',      'RTX 4070 Super 12GB',       76500, 'PCIe 4.0 x16', '12 GB GDDR6X',    220, 77000),
 (1, 'Storage',     'Samsung',     '990 Pro 2TB NVMe',          21000, 'M.2 NVMe',     '2 TB',              8, 22000),
 (1, 'Storage',     'WD',          'Blue SN580 1TB',             8500, 'M.2 NVMe',     '1 TB',              6, 0),
 (1, 'PSU',         'Corsair',     'RM750e',                    13500, 'ATX 3.0',      '80+ Gold',        750, 0),
 (1, 'Case',        'Lian Li',     'Lancool 216',               13000, 'Mid tower',    '2x 160mm front',    6, 0),
 (1, 'Cooler',      'Thermalright','Peerless Assassin 120 SE',   4200, 'AM5 / LGA1700','Dual tower air',    5, 0),
 (2, 'CPU',         'Intel',       'Core i5-12400F',            14500, 'LGA1700',      '6C / 12T',         65, 0),
 (2, 'Motherboard', 'Gigabyte',    'B760M DS3H',                15500, 'LGA1700',      'mATX',             10, 0),
 (2, 'RAM',         'Corsair',     'Vengeance 16GB (2x8) 3200',  5200, 'DDR4',         '16 GB / 3200 MT/s',  8, 0),
 (2, 'GPU',         'AMD',         'RX 6600 8GB',               26000, 'PCIe 4.0 x8',  '8 GB GDDR6',      132, 25000),
 (2, 'Storage',     'Crucial',     'P3 Plus 1TB',                7800, 'M.2 NVMe',     '1 TB',              6, 0),
 (2, 'PSU',         'Antec',       'CSK 650 Bronze',             6500, 'ATX',          '80+ Bronze',      650, 0),
 (2, 'Case',        'Deepcool',    'Matrexx 40',                 4500, 'Micro tower',  '1x 120mm rear',     3, 0),
 (2, 'Cooler',      'Deepcool',    'AK400',                      3200, 'LGA1700',      'Single tower air',  4, 0);

INSERT INTO Benchmarks (BuildId, TestName, Score, Settings, RunDate, Notes) VALUES
 (1, 'Cinebench R23 Multi', 19240, 'Stock, 24C ambient',      '{Day(96)}', 'Fans on quiet curve'),
 (1, 'Cinebench R23 Multi', 19810, 'PBO enabled, -20 CO',     '{Day(41)}', 'Peak 82C package'),
 (1, '3DMark Time Spy',     17650, 'Stock GPU clocks',        '{Day(95)}', ''),
 (1, 'Game FPS (avg)',        142, '1440p Ultra, no upscale', '{Day(28)}', 'Cyberpunk 2077 benchmark loop'),
 (1, 'Blender BMW27',          82, 'CPU only, seconds',       '{Day(26)}', 'Lower is better'),
 (2, 'Cinebench R23 Multi', 11820, 'Stock, 25C ambient',      '{Day(52)}', ''),
 (2, '3DMark Time Spy',      8140, 'Stock GPU clocks',        '{Day(51)}', ''),
 (2, 'Game FPS (avg)',         96, '1080p High, no upscale',  '{Day(20)}', 'Same benchmark loop as Creator Rig');

INSERT INTO Prices (PartId, Shop, Price, EntryDate) VALUES
 (4, 'Startech',  82000, '{Day(118)}'),
 (4, 'Ryans',     80500, '{Day(79)}'),
 (4, 'TechLand',  78000, '{Day(40)}'),
 (4, 'Startech',  76500, '{Day(11)}'),
 (1, 'Ryans',     45000, '{Day(120)}'),
 (1, 'Startech',  43500, '{Day(62)}'),
 (1, 'TechLand',  42000, '{Day(14)}'),
 (13,'Startech',  28500, '{Day(88)}'),
 (13,'Ryans',     27000, '{Day(45)}'),
 (13,'Ryans',     26000, '{Day(9)}'),
 (5, 'TechLand',  23500, '{Day(70)}'),
 (5, 'Startech',  21000, '{Day(12)}');

INSERT OR REPLACE INTO Settings (SettingKey, SettingValue) VALUES ('Seeded', '1');";

        using var seed = connection.CreateCommand();
        seed.CommandText = sql;
        await seed.ExecuteNonQueryAsync();
    }

    // ---------------------------------------------------------------- settings

    public async Task<string> GetSettingAsync(string key, string fallback)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT SettingValue FROM Settings WHERE SettingKey=@k";
        cmd.Parameters.AddWithValue("@k", key);
        var value = await cmd.ExecuteScalarAsync();
        if (value == null || value == DBNull.Value) return fallback;
        var text = value.ToString();
        return string.IsNullOrEmpty(text) ? fallback : text;
    }

    public async Task SetSettingAsync(string key, string value)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "INSERT OR REPLACE INTO Settings (SettingKey, SettingValue) VALUES (@k, @v)";
        cmd.Parameters.AddWithValue("@k", key);
        cmd.Parameters.AddWithValue("@v", value ?? string.Empty);
        await cmd.ExecuteNonQueryAsync();
    }

    // ---------------------------------------------------------------- builds

    public async Task<List<BuildModel>> GetBuildsAsync()
    {
        var builds = new List<BuildModel>();
        using var connection = await OpenAsync();

        using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText = "SELECT Id, Name, Notes, CreatedUtc FROM Builds ORDER BY Id";
            using var r = await cmd.ExecuteReaderAsync();
            while (await r.ReadAsync())
            {
                builds.Add(new BuildModel
                {
                    Id = I(r, 0),
                    Name = S(r, 1),
                    Notes = S(r, 2),
                    CreatedUtc = S(r, 3)
                });
            }
        }

        using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText = "SELECT BuildId, PartType, Price, Watts FROM Parts";
            using var r = await cmd.ExecuteReaderAsync();
            while (await r.ReadAsync())
            {
                var buildId = I(r, 0);
                var type = S(r, 1);
                var price = D(r, 2);
                var watts = I(r, 3);

                var build = builds.FirstOrDefault(b => b.Id == buildId);
                if (build == null) continue;

                build.PartCount++;
                build.TotalCost += price;
                if (string.Equals(type, "PSU", StringComparison.OrdinalIgnoreCase)) build.PsuWatts += watts;
                else build.EstimatedWatts += watts;
            }
        }

        foreach (var b in builds)
        {
            if (b.PartCount > 0) b.EstimatedWatts += 60; // board, fans, drives overhead
        }

        return builds;
    }

    public async Task<int> InsertBuildAsync(string name, string notes)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText =
            "INSERT INTO Builds (Name, Notes, CreatedUtc) VALUES (@n, @o, @c); SELECT last_insert_rowid();";
        cmd.Parameters.AddWithValue("@n", name);
        cmd.Parameters.AddWithValue("@o", notes ?? string.Empty);
        cmd.Parameters.AddWithValue("@c", DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
        var id = await cmd.ExecuteScalarAsync();
        return System.Convert.ToInt32(id, CultureInfo.InvariantCulture);
    }

    public async Task UpdateBuildAsync(int id, string name, string notes)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "UPDATE Builds SET Name=@n, Notes=@o WHERE Id=@i";
        cmd.Parameters.AddWithValue("@n", name);
        cmd.Parameters.AddWithValue("@o", notes ?? string.Empty);
        cmd.Parameters.AddWithValue("@i", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> DuplicateBuildAsync(int sourceId, string newName)
    {
        using var connection = await OpenAsync();

        int newId;
        using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText =
                "INSERT INTO Builds (Name, Notes, CreatedUtc) " +
                "SELECT @n, Notes, @c FROM Builds WHERE Id=@i; SELECT last_insert_rowid();";
            cmd.Parameters.AddWithValue("@n", newName);
            cmd.Parameters.AddWithValue("@c", DateTime.Today.ToString("yyyy-MM-dd", CultureInfo.InvariantCulture));
            cmd.Parameters.AddWithValue("@i", sourceId);
            newId = System.Convert.ToInt32(await cmd.ExecuteScalarAsync(), CultureInfo.InvariantCulture);
        }

        using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText =
                "INSERT INTO Parts (BuildId, PartType, Brand, Model, Price, SpecA, SpecB, Watts, TargetPrice, ProductUrl) " +
                "SELECT @new, PartType, Brand, Model, Price, SpecA, SpecB, Watts, TargetPrice, ProductUrl " +
                "FROM Parts WHERE BuildId=@old";
            cmd.Parameters.AddWithValue("@new", newId);
            cmd.Parameters.AddWithValue("@old", sourceId);
            await cmd.ExecuteNonQueryAsync();
        }

        return newId;
    }

    public async Task DeleteBuildAsync(int id)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = @"
DELETE FROM Prices WHERE PartId IN (SELECT Id FROM Parts WHERE BuildId=@i);
DELETE FROM Parts WHERE BuildId=@i;
DELETE FROM Benchmarks WHERE BuildId=@i;
DELETE FROM Builds WHERE Id=@i;";
        cmd.Parameters.AddWithValue("@i", id);
        await cmd.ExecuteNonQueryAsync();
    }

    // ---------------------------------------------------------------- parts

    private const string PartOrder =
        " ORDER BY CASE p.PartType WHEN 'CPU' THEN 1 WHEN 'Motherboard' THEN 2 WHEN 'RAM' THEN 3 " +
        "WHEN 'GPU' THEN 4 WHEN 'Storage' THEN 5 WHEN 'PSU' THEN 6 WHEN 'Case' THEN 7 " +
        "WHEN 'Cooler' THEN 8 ELSE 9 END, p.Id";

    private static PartModel ReadPart(DbDataReader r) => new()
    {
        Id = I(r, 0),
        BuildId = I(r, 1),
        PartType = S(r, 2),
        Brand = S(r, 3),
        Model = S(r, 4),
        Price = D(r, 5),
        SpecA = S(r, 6),
        SpecB = S(r, 7),
        Watts = I(r, 8),
        TargetPrice = D(r, 9),
        ProductUrl = S(r, 10)
    };

    public async Task<List<PartModel>> GetPartsAsync(int buildId)
    {
        var list = new List<PartModel>();
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText =
            "SELECT p.Id, p.BuildId, p.PartType, p.Brand, p.Model, p.Price, p.SpecA, p.SpecB, p.Watts, " +
            "p.TargetPrice, p.ProductUrl FROM Parts p WHERE p.BuildId=@b" + PartOrder;
        cmd.Parameters.AddWithValue("@b", buildId);
        using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) list.Add(ReadPart(r));
        return list;
    }

    public async Task<List<PartModel>> GetAllPartsAsync()
    {
        var list = new List<PartModel>();
        using var connection = await OpenAsync();

        using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText =
                "SELECT p.Id, p.BuildId, p.PartType, p.Brand, p.Model, p.Price, p.SpecA, p.SpecB, p.Watts, " +
                "p.TargetPrice, p.ProductUrl, b.Name FROM Parts p LEFT JOIN Builds b ON b.Id = p.BuildId" + PartOrder;
            using var r = await cmd.ExecuteReaderAsync();
            while (await r.ReadAsync())
            {
                var part = ReadPart(r);
                part.BuildName = S(r, 11);
                list.Add(part);
            }
        }

        var stats = await ReadPriceStatsAsync(connection);
        foreach (var part in list)
        {
            if (!stats.TryGetValue(part.Id, out var stat)) continue;
            part.LatestPrice = stat.Latest;
            part.LowestPrice = stat.Lowest;
            part.PriceEntryCount = stat.Count;
        }

        return list;
    }

    public async Task<int> InsertPartAsync(PartModel part)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText =
            "INSERT INTO Parts (BuildId, PartType, Brand, Model, Price, SpecA, SpecB, Watts, TargetPrice) " +
            "VALUES (@b, @t, @br, @m, @p, @sa, @sb, @w, @tp); SELECT last_insert_rowid();";
        AddPartParameters(cmd, part);
        return System.Convert.ToInt32(await cmd.ExecuteScalarAsync(), CultureInfo.InvariantCulture);
    }

    /// <summary>
    /// Note: ProductUrl is intentionally left alone here. The build planner's part
    /// editor has no URL field, so including the column would wipe saved URLs.
    /// Use UpdatePartUrlAsync for that column.
    /// </summary>
    public async Task UpdatePartAsync(PartModel part)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText =
            "UPDATE Parts SET BuildId=@b, PartType=@t, Brand=@br, Model=@m, Price=@p, SpecA=@sa, " +
            "SpecB=@sb, Watts=@w, TargetPrice=@tp WHERE Id=@i";
        AddPartParameters(cmd, part);
        cmd.Parameters.AddWithValue("@i", part.Id);
        await cmd.ExecuteNonQueryAsync();
    }

    private static void AddPartParameters(SqliteCommand cmd, PartModel part)
    {
        cmd.Parameters.AddWithValue("@b", part.BuildId);
        cmd.Parameters.AddWithValue("@t", part.PartType ?? "CPU");
        cmd.Parameters.AddWithValue("@br", part.Brand ?? string.Empty);
        cmd.Parameters.AddWithValue("@m", part.Model ?? string.Empty);
        cmd.Parameters.AddWithValue("@p", part.Price);
        cmd.Parameters.AddWithValue("@sa", part.SpecA ?? string.Empty);
        cmd.Parameters.AddWithValue("@sb", part.SpecB ?? string.Empty);
        cmd.Parameters.AddWithValue("@w", part.Watts);
        cmd.Parameters.AddWithValue("@tp", part.TargetPrice);
    }

    public async Task UpdatePartTargetAsync(int partId, double target)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "UPDATE Parts SET TargetPrice=@t WHERE Id=@i";
        cmd.Parameters.AddWithValue("@t", target);
        cmd.Parameters.AddWithValue("@i", partId);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task UpdatePartUrlAsync(int partId, string url)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "UPDATE Parts SET ProductUrl=@u WHERE Id=@i";
        cmd.Parameters.AddWithValue("@u", url ?? string.Empty);
        cmd.Parameters.AddWithValue("@i", partId);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeletePartAsync(int partId)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM Prices WHERE PartId=@i; DELETE FROM Parts WHERE Id=@i;";
        cmd.Parameters.AddWithValue("@i", partId);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> CountPartsAsync()
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM Parts";
        return System.Convert.ToInt32(await cmd.ExecuteScalarAsync(), CultureInfo.InvariantCulture);
    }

    // ---------------------------------------------------------------- benchmarks

    public async Task<List<BenchmarkRun>> GetBenchmarksAsync(int buildId, string testName, int limit)
    {
        var list = new List<BenchmarkRun>();
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText =
            "SELECT r.Id, r.BuildId, r.TestName, r.Score, r.Settings, r.RunDate, r.Notes, b.Name " +
            "FROM Benchmarks r LEFT JOIN Builds b ON b.Id = r.BuildId " +
            "WHERE (@b = 0 OR r.BuildId = @b) AND (@t = '' OR r.TestName = @t) " +
            "ORDER BY r.RunDate DESC, r.Id DESC" + (limit > 0 ? " LIMIT " + limit : string.Empty);
        cmd.Parameters.AddWithValue("@b", buildId);
        cmd.Parameters.AddWithValue("@t", testName ?? string.Empty);

        using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            list.Add(new BenchmarkRun
            {
                Id = I(r, 0),
                BuildId = I(r, 1),
                TestName = S(r, 2),
                Score = D(r, 3),
                Settings = S(r, 4),
                RunDate = S(r, 5),
                Notes = S(r, 6),
                BuildName = S(r, 7)
            });
        }
        return list;
    }

    public async Task<List<string>> GetTestNamesAsync()
    {
        var list = new List<string>();
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT DISTINCT TestName FROM Benchmarks ORDER BY TestName";
        using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync()) list.Add(S(r, 0));
        return list;
    }

    public async Task InsertBenchmarkAsync(BenchmarkRun run)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText =
            "INSERT INTO Benchmarks (BuildId, TestName, Score, Settings, RunDate, Notes) " +
            "VALUES (@b, @t, @s, @st, @d, @n)";
        cmd.Parameters.AddWithValue("@b", run.BuildId);
        cmd.Parameters.AddWithValue("@t", run.TestName ?? string.Empty);
        cmd.Parameters.AddWithValue("@s", run.Score);
        cmd.Parameters.AddWithValue("@st", run.Settings ?? string.Empty);
        cmd.Parameters.AddWithValue("@d", run.RunDate ?? string.Empty);
        cmd.Parameters.AddWithValue("@n", run.Notes ?? string.Empty);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeleteBenchmarkAsync(int id)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM Benchmarks WHERE Id=@i";
        cmd.Parameters.AddWithValue("@i", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> CountBenchmarksAsync()
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM Benchmarks";
        return System.Convert.ToInt32(await cmd.ExecuteScalarAsync(), CultureInfo.InvariantCulture);
    }

    // ---------------------------------------------------------------- prices

    public async Task<List<PriceEntry>> GetPricesAsync(int partId)
    {
        var list = new List<PriceEntry>();
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText =
            "SELECT Id, PartId, Shop, Price, EntryDate FROM Prices WHERE PartId=@p ORDER BY EntryDate, Id";
        cmd.Parameters.AddWithValue("@p", partId);
        using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            list.Add(new PriceEntry
            {
                Id = I(r, 0),
                PartId = I(r, 1),
                Shop = S(r, 2),
                Price = D(r, 3),
                EntryDate = S(r, 4)
            });
        }
        return list;
    }

    public async Task InsertPriceAsync(PriceEntry entry)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "INSERT INTO Prices (PartId, Shop, Price, EntryDate) VALUES (@p, @s, @pr, @d)";
        cmd.Parameters.AddWithValue("@p", entry.PartId);
        cmd.Parameters.AddWithValue("@s", entry.Shop ?? string.Empty);
        cmd.Parameters.AddWithValue("@pr", entry.Price);
        cmd.Parameters.AddWithValue("@d", entry.EntryDate ?? string.Empty);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task DeletePriceAsync(int id)
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "DELETE FROM Prices WHERE Id=@i";
        cmd.Parameters.AddWithValue("@i", id);
        await cmd.ExecuteNonQueryAsync();
    }

    public async Task<int> CountPricesAsync()
    {
        using var connection = await OpenAsync();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT COUNT(*) FROM Prices";
        return System.Convert.ToInt32(await cmd.ExecuteScalarAsync(), CultureInfo.InvariantCulture);
    }

    private static async Task<Dictionary<int, PriceStat>> ReadPriceStatsAsync(SqliteConnection connection)
    {
        var map = new Dictionary<int, PriceStat>();
        using var cmd = connection.CreateCommand();
        cmd.CommandText = "SELECT PartId, Price, Shop, EntryDate FROM Prices ORDER BY PartId, EntryDate, Id";
        using var r = await cmd.ExecuteReaderAsync();
        while (await r.ReadAsync())
        {
            var partId = I(r, 0);
            var price = D(r, 1);
            var shop = S(r, 2);
            var date = S(r, 3);

            if (!map.TryGetValue(partId, out var stat))
            {
                stat = new PriceStat { Lowest = price };
                map[partId] = stat;
            }

            stat.Previous = stat.Count == 0 ? 0 : stat.Latest;
            stat.Latest = price;
            stat.LatestShop = shop;
            stat.LatestDate = date;
            stat.Count++;
            if (price < stat.Lowest || stat.Lowest <= 0) stat.Lowest = price;
        }
        return map;
    }

    public async Task<List<PriceDropItem>> GetRecentPriceDropsAsync(int take)
    {
        var drops = new List<PriceDropItem>();
        using var connection = await OpenAsync();

        var stats = await ReadPriceStatsAsync(connection);
        if (stats.Count == 0) return drops;

        var parts = new Dictionary<int, (string title, string build)>();
        using (var cmd = connection.CreateCommand())
        {
            cmd.CommandText =
                "SELECT p.Id, p.Brand, p.Model, b.Name FROM Parts p LEFT JOIN Builds b ON b.Id = p.BuildId";
            using var r = await cmd.ExecuteReaderAsync();
            while (await r.ReadAsync())
            {
                var title = (S(r, 1) + " " + S(r, 2)).Trim();
                parts[I(r, 0)] = (string.IsNullOrWhiteSpace(title) ? "(unnamed part)" : title, S(r, 3));
            }
        }

        foreach (var kv in stats)
        {
            var stat = kv.Value;
            if (stat.Count < 2 || stat.Previous <= 0) continue;
            if (stat.Latest >= stat.Previous) continue;
            if (!parts.TryGetValue(kv.Key, out var info)) continue;

            drops.Add(new PriceDropItem
            {
                PartTitle = info.title,
                BuildName = string.IsNullOrWhiteSpace(info.build) ? "Unassigned" : info.build,
                Shop = string.IsNullOrWhiteSpace(stat.LatestShop) ? "Unknown shop" : stat.LatestShop,
                EntryDate = stat.LatestDate,
                OldPrice = stat.Previous,
                NewPrice = stat.Latest
            });
        }

        return drops.OrderByDescending(d => d.Drop).Take(take).ToList();
    }
}
