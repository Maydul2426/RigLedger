﻿using System;
using System.Globalization;
using System.Net.Http;
using System.Text.Json;
using System.Threading.Tasks;

namespace RigLedger.Services;

public class RateResult
{
    public bool Success { get; set; }
    public string Message { get; set; } = "";
}

public class ExchangeRateService
{
    private const int TimeoutSeconds = 10;
    private const string Endpoint = "https://open.er-api.com/v6/latest/";
    private const double StaleAfterHours = 12;

    private readonly HttpClient _http;
    private readonly DatabaseService _db;
    private readonly ConnectivityService _connectivity;

    public ExchangeRateService(DatabaseService db, ConnectivityService connectivity)
    {
        _db = db;
        _connectivity = connectivity;
        _http = new HttpClient { Timeout = TimeSpan.FromSeconds(TimeoutSeconds) };
        _http.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", "RigLedger/1.1");
    }

    public static string Normalize(string code)
        => (code ?? string.Empty).Trim().ToUpperInvariant();

    public async Task<RateResult> RefreshAsync(string baseCode)
    {
        var result = new RateResult();
        var code = Normalize(baseCode);

        if (code.Length < 3)
        {
            result.Message = "Enter a three letter currency code, for example BDT.";
            return result;
        }

        try
        {
            using var response = await _http.GetAsync(Endpoint + code);
            var body = await response.Content.ReadAsStringAsync();
            _connectivity.ReportSuccess();

            if (!response.IsSuccessStatusCode)
            {
                result.Message = "The rate service replied with error " + (int)response.StatusCode + ".";
                return result;
            }

            using var doc = JsonDocument.Parse(body);
            var root = doc.RootElement;

            if (!root.TryGetProperty("result", out var status) ||
                !string.Equals(status.GetString(), "success", StringComparison.OrdinalIgnoreCase))
            {
                result.Message = "The rate service does not recognise the code \"" + code + "\".";
                return result;
            }

            if (!root.TryGetProperty("rates", out var rates) || rates.ValueKind != JsonValueKind.Object)
            {
                result.Message = "The rate service sent an answer I could not read.";
                return result;
            }

            await _db.SetSettingAsync("RatesBase", code);
            await _db.SetSettingAsync("RatesJson", rates.GetRawText());
            await _db.SetSettingAsync("RatesUpdated",
                DateTime.Now.ToString("yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture));

            result.Success = true;
            result.Message = "Rates updated just now.";
        }
        catch (TaskCanceledException)
        {
            result.Message = "The rate service did not answer within 10 seconds.";
        }
        catch (TimeoutException)
        {
            result.Message = "The rate service did not answer within 10 seconds.";
        }
        catch (HttpRequestException)
        {
            _connectivity.ReportFailure();
            result.Message = "Could not reach the rate service. Cached rates will be used instead.";
        }
        catch (Exception ex)
        {
            result.Message = "Could not update rates: " + ex.Message;
        }

        return result;
    }

    public async Task<double?> GetCachedRateAsync(string baseCode, string targetCode)
    {
        var wanted = Normalize(baseCode);
        var target = Normalize(targetCode);

        if (wanted.Length == 0 || target.Length == 0) return null;
        if (wanted == target) return 1.0;

        try
        {
            var storedBase = Normalize(await _db.GetSettingAsync("RatesBase", string.Empty));
            if (storedBase != wanted) return null;

            var json = await _db.GetSettingAsync("RatesJson", string.Empty);
            if (string.IsNullOrWhiteSpace(json)) return null;

            using var doc = JsonDocument.Parse(json);
            if (!doc.RootElement.TryGetProperty(target, out var value)) return null;
            if (value.ValueKind != JsonValueKind.Number) return null;

            var rate = value.GetDouble();
            return rate > 0 ? rate : (double?)null;
        }
        catch
        {
            return null;
        }
    }

    /// <summary>Cached value when fresh, otherwise a refresh attempt, otherwise whatever is cached.</summary>
    public async Task<double?> GetRateAsync(string baseCode, string targetCode)
    {
        var cached = await GetCachedRateAsync(baseCode, targetCode);

        var stale = true;
        var updated = await _db.GetSettingAsync("RatesUpdated", string.Empty);
        if (DateTime.TryParseExact(updated, "yyyy-MM-dd HH:mm", CultureInfo.InvariantCulture,
                DateTimeStyles.None, out var when))
        {
            stale = (DateTime.Now - when).TotalHours > StaleAfterHours;
        }

        if (cached.HasValue && !stale) return cached;

        if (_connectivity.IsOnline)
        {
            var refresh = await RefreshAsync(baseCode);
            if (refresh.Success) return await GetCachedRateAsync(baseCode, targetCode);
        }

        return cached;
    }

    public async Task<string> GetLastUpdatedAsync()
    {
        var updated = await _db.GetSettingAsync("RatesUpdated", string.Empty);
        return string.IsNullOrWhiteSpace(updated) ? "Never updated" : "Last updated " + updated;
    }
}
