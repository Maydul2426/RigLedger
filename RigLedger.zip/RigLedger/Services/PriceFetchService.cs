﻿using System;
using System.Globalization;
using System.Linq;
using System.Net.Http;
using System.Text.Json;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace RigLedger.Services;

public class PriceFetchResult
{
    public bool Success { get; set; }
    public double Price { get; set; }
    public string Shop { get; set; } = "";
    public string Method { get; set; } = "";
    public string Message { get; set; } = "";
}

public class PriceFetchService
{
    private const int TimeoutSeconds = 10;

    private readonly HttpClient _http;
    private readonly ConnectivityService _connectivity;

    public PriceFetchService(ConnectivityService connectivity)
    {
        _connectivity = connectivity;
        _http = new HttpClient { Timeout = TimeSpan.FromSeconds(TimeoutSeconds) };
        _http.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent",
            "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 RigLedger/1.1");
        _http.DefaultRequestHeaders.TryAddWithoutValidation("Accept",
            "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8");
        _http.DefaultRequestHeaders.TryAddWithoutValidation("Accept-Language", "en-US,en;q=0.9");
    }

    public static string ShopFromUrl(string url)
    {
        try
        {
            if (!Uri.TryCreate((url ?? string.Empty).Trim(), UriKind.Absolute, out var uri)) return "Online shop";
            var host = uri.Host;
            if (host.StartsWith("www.", StringComparison.OrdinalIgnoreCase)) host = host.Substring(4);
            return string.IsNullOrWhiteSpace(host) ? "Online shop" : host;
        }
        catch
        {
            return "Online shop";
        }
    }

    public async Task<PriceFetchResult> FetchAsync(string url)
    {
        var result = new PriceFetchResult();

        if (string.IsNullOrWhiteSpace(url))
        {
            result.Message = "No product URL saved for this part.";
            return result;
        }

        if (!Uri.TryCreate(url.Trim(), UriKind.Absolute, out var uri) ||
            (uri.Scheme != Uri.UriSchemeHttp && uri.Scheme != Uri.UriSchemeHttps))
        {
            result.Message = "That is not a valid web address. It should start with https://";
            return result;
        }

        result.Shop = ShopFromUrl(url);

        string html;
        try
        {
            using var response = await _http.GetAsync(uri);
            if (!response.IsSuccessStatusCode)
            {
                _connectivity.ReportSuccess();
                result.Message = "The shop replied with error " + (int)response.StatusCode +
                                 ". The page may have moved or be blocking automated visits.";
                return result;
            }

            html = await response.Content.ReadAsStringAsync();
            _connectivity.ReportSuccess();
        }
        catch (TaskCanceledException)
        {
            result.Message = "The shop did not answer within 10 seconds. Try again later.";
            return result;
        }
        catch (TimeoutException)
        {
            result.Message = "The shop did not answer within 10 seconds. Try again later.";
            return result;
        }
        catch (HttpRequestException)
        {
            _connectivity.ReportFailure();
            result.Message = "Could not reach the site. Check your internet connection or the address.";
            return result;
        }
        catch (Exception ex)
        {
            result.Message = "Could not read the page: " + ex.Message;
            return result;
        }

        if (string.IsNullOrWhiteSpace(html))
        {
            result.Message = "The page came back empty.";
            return result;
        }

        if (html.Length > 1500000) html = html.Substring(0, 1500000);

        try
        {
            if (TryJsonLd(html, out var p1) && p1 > 0)
            {
                result.Success = true;
                result.Price = p1;
                result.Method = "structured product data";
                return result;
            }

            if (TryMeta(html, out var p2) && p2 > 0)
            {
                result.Success = true;
                result.Price = p2;
                result.Method = "page meta tags";
                return result;
            }

            if (TryPattern(html, out var p3) && p3 > 0)
            {
                result.Success = true;
                result.Price = p3;
                result.Method = "text pattern match";
                return result;
            }
        }
        catch (Exception ex)
        {
            result.Message = "The page loaded but could not be read: " + ex.Message;
            return result;
        }

        result.Message = "Loaded the page, but found no price I could read. Log it by hand instead.";
        return result;
    }

    // ------------------------------------------------------------ (a) JSON-LD

    private static bool TryJsonLd(string html, out double price)
    {
        price = 0;

        var matches = Regex.Matches(html,
            "<script[^>]*type\\s*=\\s*[\"']application/ld\\+json[\"'][^>]*>(.*?)</script>",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);

        foreach (Match m in matches)
        {
            var json = m.Groups[1].Value.Trim();
            if (json.Length == 0) continue;

            try
            {
                using var doc = JsonDocument.Parse(json);
                if (FindPrice(doc.RootElement, 0, out price) && price > 0) return true;
            }
            catch
            {
                // Malformed block on the page. Move on to the next one.
            }
        }

        return false;
    }

    private static bool FindPrice(JsonElement element, int depth, out double price)
    {
        price = 0;
        if (depth > 8) return false;

        if (element.ValueKind == JsonValueKind.Array)
        {
            foreach (var item in element.EnumerateArray())
                if (FindPrice(item, depth + 1, out price) && price > 0) return true;
            return false;
        }

        if (element.ValueKind != JsonValueKind.Object) return false;

        foreach (var prop in element.EnumerateObject())
        {
            if (!prop.NameEquals("price") && !prop.NameEquals("lowPrice") && !prop.NameEquals("highPrice"))
                continue;

            string raw = null;
            if (prop.Value.ValueKind == JsonValueKind.Number) raw = prop.Value.GetRawText();
            else if (prop.Value.ValueKind == JsonValueKind.String) raw = prop.Value.GetString();

            if (raw != null && TryParseNumber(raw, out price) && price > 0) return true;
        }

        foreach (var prop in element.EnumerateObject())
        {
            if (prop.Value.ValueKind == JsonValueKind.Object || prop.Value.ValueKind == JsonValueKind.Array)
                if (FindPrice(prop.Value, depth + 1, out price) && price > 0) return true;
        }

        return false;
    }

    // ------------------------------------------------------------ (b) meta tags

    private static readonly string[] MetaKeys =
    {
        "og:price:amount",
        "product:price:amount",
        "og:product:price:amount"
    };

    private static bool TryMeta(string html, out double price)
    {
        price = 0;

        foreach (var key in MetaKeys)
        {
            var escaped = Regex.Escape(key);

            var a = Regex.Match(html,
                "<meta[^>]+(?:property|name|itemprop)\\s*=\\s*[\"']" + escaped +
                "[\"'][^>]*content\\s*=\\s*[\"']([^\"']+)[\"']",
                RegexOptions.IgnoreCase);
            if (a.Success && TryParseNumber(a.Groups[1].Value, out price) && price > 0) return true;

            var b = Regex.Match(html,
                "<meta[^>]+content\\s*=\\s*[\"']([^\"']+)[\"'][^>]*(?:property|name|itemprop)\\s*=\\s*[\"']" +
                escaped + "[\"']",
                RegexOptions.IgnoreCase);
            if (b.Success && TryParseNumber(b.Groups[1].Value, out price) && price > 0) return true;
        }

        var c = Regex.Match(html,
            "itemprop\\s*=\\s*[\"']price[\"'][^>]*content\\s*=\\s*[\"']([^\"']+)[\"']",
            RegexOptions.IgnoreCase);
        if (c.Success && TryParseNumber(c.Groups[1].Value, out price) && price > 0) return true;

        return false;
    }

    // ------------------------------------------------------------ (c) fallback

    private static bool TryPattern(string html, out double price)
    {
        price = 0;

        var text = Regex.Replace(html, "<script.*?</script>", " ",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);
        text = Regex.Replace(text, "<style.*?</style>", " ",
            RegexOptions.IgnoreCase | RegexOptions.Singleline);
        text = Regex.Replace(text, "<[^>]+>", " ");
        text = System.Net.WebUtility.HtmlDecode(text);

        var patterns = new[]
        {
            "(?:\u09F3|BDT|Tk\\.?)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)",
            "([0-9][0-9,]*(?:\\.[0-9]{1,2})?)\\s*(?:\u09F3|BDT|Tk\\b)",
            "(?:\\$|USD|\u20AC|EUR|\u00A3|GBP|\u20B9|INR)\\s*([0-9][0-9,]*(?:\\.[0-9]{1,2})?)"
        };

        foreach (var pattern in patterns)
        {
            foreach (Match m in Regex.Matches(text, pattern, RegexOptions.IgnoreCase))
            {
                if (TryParseNumber(m.Groups[1].Value, out price) && price >= 1) return true;
            }
        }

        return false;
    }

    // ------------------------------------------------------------ number parsing

    /// <summary>
    /// Handles 76500, 76,500, 1,23,500 (Indian/Bangladeshi grouping) and 1,234.56.
    /// </summary>
    public static bool TryParseNumber(string raw, out double value)
    {
        value = 0;
        if (string.IsNullOrWhiteSpace(raw)) return false;

        var cleaned = new string(raw.Where(c => char.IsDigit(c) || c == '.' || c == ',').ToArray());
        if (cleaned.Length == 0) return false;

        cleaned = cleaned.Replace(",", string.Empty);

        var firstDot = cleaned.IndexOf('.');
        var lastDot = cleaned.LastIndexOf('.');
        if (firstDot >= 0 && firstDot != lastDot)
        {
            cleaned = cleaned.Substring(0, lastDot).Replace(".", string.Empty) + cleaned.Substring(lastDot);
        }

        if (cleaned.StartsWith(".", StringComparison.Ordinal)) return false;

        return double.TryParse(cleaned, NumberStyles.Any, CultureInfo.InvariantCulture, out value);
    }
}
