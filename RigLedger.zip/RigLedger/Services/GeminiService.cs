﻿using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Text;
using System.Text.Json;
using System.Text.Json.Nodes;
using System.Threading.Tasks;
using RigLedger.Models;

namespace RigLedger.Services;

public class GeminiResult
{
    public bool Success { get; set; }
    public string Text { get; set; } = "";
    public string Message { get; set; } = "";
}

public class GeminiService
{
    public const string DefaultModel = "gemini-2.5-flash";

    // Raise this to 30 if long answers ever time out.
    private const int TimeoutSeconds = 10;

    private const string Endpoint = "https://generativelanguage.googleapis.com/v1beta/models/";

    private readonly HttpClient _http;
    private readonly ConnectivityService _connectivity;

    public GeminiService(ConnectivityService connectivity)
    {
        _connectivity = connectivity;
        _http = new HttpClient { Timeout = TimeSpan.FromSeconds(TimeoutSeconds) };
        _http.DefaultRequestHeaders.TryAddWithoutValidation("User-Agent", "RigLedger/1.1");
    }

    public Task<GeminiResult> TestAsync(string apiKey, string model)
    {
        var probe = new List<ChatMessage> { new ChatMessage { IsUser = true, Text = "ping" } };
        return SendAsync(apiKey, model, "Reply with the single word: ready.", probe);
    }

    public async Task<GeminiResult> SendAsync(string apiKey, string model, string systemText,
        IEnumerable<ChatMessage> history)
    {
        var result = new GeminiResult();

        if (string.IsNullOrWhiteSpace(apiKey))
        {
            result.Message = "No Gemini API key saved yet. Add one on the Settings page.";
            return result;
        }

        var modelName = string.IsNullOrWhiteSpace(model) ? DefaultModel : model.Trim();

        JsonObject root;
        try
        {
            root = new JsonObject();

            if (!string.IsNullOrWhiteSpace(systemText))
            {
                root["system_instruction"] = new JsonObject
                {
                    ["parts"] = new JsonArray(new JsonObject { ["text"] = systemText })
                };
            }

            var contents = new JsonArray();
            var any = false;

            foreach (var message in history)
            {
                if (message == null || string.IsNullOrWhiteSpace(message.Text)) continue;
                any = true;
                contents.Add(new JsonObject
                {
                    ["role"] = message.IsUser ? "user" : "model",
                    ["parts"] = new JsonArray(new JsonObject { ["text"] = message.Text })
                });
            }

            if (!any)
            {
                result.Message = "There is nothing to send yet.";
                return result;
            }

            root["contents"] = contents;
            root["generationConfig"] = new JsonObject
            {
                ["temperature"] = 0.4,
                ["maxOutputTokens"] = 1024
            };
        }
        catch (Exception ex)
        {
            result.Message = "Could not build the request: " + ex.Message;
            return result;
        }

        try
        {
            using var request = new HttpRequestMessage(HttpMethod.Post, Endpoint + modelName + ":generateContent");
            request.Headers.TryAddWithoutValidation("x-goog-api-key", apiKey.Trim());
            request.Content = new StringContent(root.ToJsonString(), Encoding.UTF8, "application/json");

            using var response = await _http.SendAsync(request);
            var body = await response.Content.ReadAsStringAsync();
            _connectivity.ReportSuccess();

            if (!response.IsSuccessStatusCode)
            {
                result.Message = DescribeError((int)response.StatusCode, body);
                return result;
            }

            using var doc = JsonDocument.Parse(body);
            var text = new StringBuilder();

            if (doc.RootElement.TryGetProperty("candidates", out var candidates) &&
                candidates.ValueKind == JsonValueKind.Array && candidates.GetArrayLength() > 0)
            {
                var first = candidates[0];

                if (first.TryGetProperty("content", out var content) &&
                    content.TryGetProperty("parts", out var parts) &&
                    parts.ValueKind == JsonValueKind.Array)
                {
                    foreach (var part in parts.EnumerateArray())
                    {
                        if (part.TryGetProperty("text", out var t) && t.ValueKind == JsonValueKind.String)
                            text.Append(t.GetString());
                    }
                }

                if (text.Length == 0 && first.TryGetProperty("finishReason", out var reason))
                {
                    result.Message = "The model stopped before writing anything (reason: " +
                                     reason.GetString() + "). Try rewording the question.";
                }
            }

            if (text.Length == 0)
            {
                if (string.IsNullOrEmpty(result.Message))
                    result.Message = "The model answered but sent no text back. Try again.";
                return result;
            }

            result.Success = true;
            result.Text = text.ToString().Trim();
            return result;
        }
        catch (TaskCanceledException)
        {
            result.Message = "Gemini did not answer within " + TimeoutSeconds + " seconds. Try a shorter question.";
            return result;
        }
        catch (TimeoutException)
        {
            result.Message = "Gemini did not answer within " + TimeoutSeconds + " seconds. Try a shorter question.";
            return result;
        }
        catch (HttpRequestException)
        {
            _connectivity.ReportFailure();
            result.Message = "Could not reach Gemini. The assistant needs an internet connection; " +
                             "everything else in RigLedger keeps working offline.";
            return result;
        }
        catch (Exception ex)
        {
            result.Message = "Something went wrong talking to Gemini: " + ex.Message;
            return result;
        }
    }

    private static string DescribeError(int status, string body)
    {
        var detail = ExtractMessage(body);

        switch (status)
        {
            case 400:
                return "Gemini rejected the request (400). Usually the API key is wrong, or the model name is misspelt." + detail;
            case 401:
            case 403:
                return "Gemini refused the key (" + status + "). Check the key on the Settings page, and that the " +
                       "Generative Language API is switched on for it." + detail;
            case 404:
                return "Gemini has no model with that name (404). Check the model name on the Settings page." + detail;
            case 429:
                return "You have hit Gemini's rate limit (429). Wait a minute and try again." + detail;
            default:
                if (status >= 500)
                    return "Gemini is having trouble on its side (" + status + "). Try again shortly." + detail;
                return "Gemini returned error " + status + "." + detail;
        }
    }

    private static string ExtractMessage(string body)
    {
        if (string.IsNullOrWhiteSpace(body)) return string.Empty;

        try
        {
            using var doc = JsonDocument.Parse(body);
            if (doc.RootElement.TryGetProperty("error", out var error) &&
                error.TryGetProperty("message", out var message) &&
                message.ValueKind == JsonValueKind.String)
            {
                var text = message.GetString() ?? string.Empty;
                if (text.Length > 200) text = text.Substring(0, 200) + "…";
                return string.IsNullOrWhiteSpace(text) ? string.Empty : "\n\nDetails: " + text;
            }
        }
        catch
        {
            // Not JSON. Nothing useful to add.
        }

        return string.Empty;
    }
}
