using System.Globalization;

namespace RigLedger.Services;

public static class Money
{
    public static string Symbol { get; set; } = "\u09F3"; // BDT taka sign

    public static string Format(double value)
        => Symbol + value.ToString("#,##0.##", CultureInfo.InvariantCulture);

    public static string FormatCompact(double value)
    {
        if (value >= 1_000_000) return Symbol + (value / 1_000_000).ToString("0.#", CultureInfo.InvariantCulture) + "M";
        if (value >= 1_000) return Symbol + (value / 1_000).ToString("0.#", CultureInfo.InvariantCulture) + "k";
        return Format(value);
    }
}
