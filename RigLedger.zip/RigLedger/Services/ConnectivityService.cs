﻿using System;
using System.Net.NetworkInformation;
using System.Windows.Threading;
using CommunityToolkit.Mvvm.ComponentModel;

namespace RigLedger.Services;

/// <summary>
/// Cheap online/offline signal. Polls the network adapter state every 20 seconds
/// (no traffic), and the HTTP services correct it after every real call.
/// </summary>
public partial class ConnectivityService : ObservableObject
{
    private readonly DispatcherTimer _timer;

    [ObservableProperty] private bool _isOnline;
    [ObservableProperty] private string _statusText = "Checking network";

    public ConnectivityService()
    {
        _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(20) };
        _timer.Tick += (_, _) => CheckNetwork();
        _timer.Start();
        CheckNetwork();
    }

    public void CheckNetwork()
    {
        try
        {
            SetState(NetworkInterface.GetIsNetworkAvailable());
        }
        catch
        {
            SetState(false);
        }
    }

    public void ReportSuccess() => SetState(true);

    public void ReportFailure() => SetState(false);

    private void SetState(bool online)
    {
        IsOnline = online;
        StatusText = online ? "Online" : "Offline";
    }
}
