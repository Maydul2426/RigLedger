@echo off
title RigLedger
cd /d "%~dp0"
echo Starting RigLedger. The first run takes a minute while it downloads and builds.
echo.
dotnet run
echo.
echo RigLedger has closed. Press any key to close this window.
pause >nul
