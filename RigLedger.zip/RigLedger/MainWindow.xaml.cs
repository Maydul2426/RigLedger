using System.Windows;

namespace RigLedger;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
