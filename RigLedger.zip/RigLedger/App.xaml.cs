﻿using System;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Threading;
using RigLedger.Services;
using RigLedger.ViewModels;

namespace RigLedger;

public partial class App : Application
{
    protected override async void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        DispatcherUnhandledException += OnDispatcherUnhandledException;

        try
        {
            var db = new DatabaseService();
            await db.InitializeAsync();

            var theme = new ThemeService();
            var themeSetting = await db.GetSettingAsync("Theme", "Light");
            var isDark = string.Equals(themeSetting, "Dark", StringComparison.OrdinalIgnoreCase);
            theme.Apply(isDark);

            Money.Symbol = await db.GetSettingAsync("Currency", "\u09F3");

            var connectivity = new ConnectivityService();
            var rates = new ExchangeRateService(db, connectivity);
            var priceFetch = new PriceFetchService(connectivity);
            var gemini = new GeminiService(connectivity);

            var main = new MainViewModel(db, theme, isDark, connectivity, rates, priceFetch, gemini);
            await main.LoadAsync();

            var window = new MainWindow { DataContext = main };
            MainWindow = window;
            window.Show();
        }
        catch (Exception ex)
        {
            MessageBox.Show(
                "RigLedger could not start.\n\n" + ex.Message,
                "RigLedger", MessageBoxButton.OK, MessageBoxImage.Error);
            Shutdown();
        }
    }

    private void OnDispatcherUnhandledException(object sender, DispatcherUnhandledExceptionEventArgs e)
    {
        MessageBox.Show(
            "Something went wrong, but RigLedger will keep running.\n\n" + e.Exception.Message,
            "RigLedger", MessageBoxButton.OK, MessageBoxImage.Warning);
        e.Handled = true;
    }
}
