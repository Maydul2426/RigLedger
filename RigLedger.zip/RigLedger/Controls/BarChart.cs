using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using RigLedger.Models;

namespace RigLedger.Controls;

public class BarChart : UserControl
{
    private readonly Canvas _canvas = new() { ClipToBounds = true };

    public static readonly DependencyProperty ItemsSourceProperty = DependencyProperty.Register(
        nameof(ItemsSource), typeof(IEnumerable), typeof(BarChart),
        new PropertyMetadata(null, OnItemsSourceChanged));

    public IEnumerable ItemsSource
    {
        get => (IEnumerable)GetValue(ItemsSourceProperty);
        set => SetValue(ItemsSourceProperty, value);
    }

    public BarChart()
    {
        Content = _canvas;
        HorizontalAlignment = HorizontalAlignment.Stretch;
        VerticalAlignment = VerticalAlignment.Stretch;
        SizeChanged += (_, _) => Redraw();
        Loaded += (_, _) => Redraw();
    }

    private static void OnItemsSourceChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        => ((BarChart)d).Redraw();

    private Brush Res(string key, Brush fallback)
        => TryFindResource(key) as Brush ?? fallback;

    private void Redraw()
    {
        _canvas.Children.Clear();

        var width = ActualWidth;
        var height = ActualHeight;
        if (width < 40 || height < 40) return;

        var textBrush = Res("TextBrush", Brushes.Black);
        var mutedBrush = Res("MutedBrush", Brushes.Gray);
        var gridBrush = Res("ChartGridBrush", Brushes.LightGray);

        var items = ItemsSource?.OfType<ChartPoint>().ToList() ?? new List<ChartPoint>();
        if (items.Count == 0)
        {
            AddCenteredMessage("No benchmark data to compare yet.", mutedBrush, width, height);
            return;
        }

        var palette = new List<Brush>
        {
            Res("PrimaryBrush", Brushes.MediumPurple),
            Res("MintBrush", Brushes.MediumAquamarine),
            Res("SkyBrush", Brushes.LightSkyBlue),
            Res("PeachBrush", Brushes.PeachPuff),
            Res("RoseBrush", Brushes.LightPink)
        };

        const double bottomArea = 28;
        const double topArea = 24;
        var plotHeight = Math.Max(10, height - bottomArea - topArea);
        var max = items.Max(i => i.Value);
        if (max <= 0) max = 1;

        var baseline = new Line
        {
            X1 = 0,
            X2 = width,
            Y1 = height - bottomArea,
            Y2 = height - bottomArea,
            Stroke = gridBrush,
            StrokeThickness = 1
        };
        _canvas.Children.Add(baseline);

        var slot = width / items.Count;
        var barWidth = Math.Min(64, Math.Max(18, slot * 0.5));

        for (var i = 0; i < items.Count; i++)
        {
            var point = items[i];
            var barHeight = Math.Max(2, point.Value / max * plotHeight);
            var x = slot * i + (slot - barWidth) / 2;
            var y = height - bottomArea - barHeight;

            var rect = new Rectangle
            {
                Width = barWidth,
                Height = barHeight,
                RadiusX = 7,
                RadiusY = 7,
                Fill = point.Fill ?? palette[i % palette.Count]
            };
            Canvas.SetLeft(rect, x);
            Canvas.SetTop(rect, y);
            _canvas.Children.Add(rect);

            var value = new TextBlock
            {
                Text = point.Value.ToString("#,##0.##"),
                FontSize = 11.5,
                Foreground = textBrush,
                TextAlignment = TextAlignment.Center,
                Width = slot
            };
            Canvas.SetLeft(value, slot * i);
            Canvas.SetTop(value, Math.Max(0, y - 19));
            _canvas.Children.Add(value);

            var label = new TextBlock
            {
                Text = point.Label,
                FontSize = 11,
                Foreground = mutedBrush,
                TextAlignment = TextAlignment.Center,
                TextTrimming = TextTrimming.CharacterEllipsis,
                Width = Math.Max(10, slot - 6)
            };
            Canvas.SetLeft(label, slot * i + 3);
            Canvas.SetTop(label, height - bottomArea + 7);
            _canvas.Children.Add(label);
        }
    }

    private void AddCenteredMessage(string message, Brush brush, double width, double height)
    {
        var text = new TextBlock
        {
            Text = message,
            FontSize = 12.5,
            Foreground = brush,
            Width = width,
            TextAlignment = TextAlignment.Center
        };
        Canvas.SetLeft(text, 0);
        Canvas.SetTop(text, height / 2 - 10);
        _canvas.Children.Add(text);
    }
}
