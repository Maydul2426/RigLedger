using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;
using System.Windows.Shapes;
using RigLedger.Models;
using RigLedger.Services;

namespace RigLedger.Controls;

public class LineChart : UserControl
{
    private readonly Canvas _canvas = new() { ClipToBounds = true };

    public static readonly DependencyProperty ItemsSourceProperty = DependencyProperty.Register(
        nameof(ItemsSource), typeof(IEnumerable), typeof(LineChart),
        new PropertyMetadata(null, OnAnyChanged));

    public static readonly DependencyProperty TargetValueProperty = DependencyProperty.Register(
        nameof(TargetValue), typeof(double), typeof(LineChart),
        new PropertyMetadata(0d, OnAnyChanged));

    public IEnumerable ItemsSource
    {
        get => (IEnumerable)GetValue(ItemsSourceProperty);
        set => SetValue(ItemsSourceProperty, value);
    }

    public double TargetValue
    {
        get => (double)GetValue(TargetValueProperty);
        set => SetValue(TargetValueProperty, value);
    }

    public LineChart()
    {
        Content = _canvas;
        HorizontalAlignment = HorizontalAlignment.Stretch;
        VerticalAlignment = VerticalAlignment.Stretch;
        SizeChanged += (_, _) => Redraw();
        Loaded += (_, _) => Redraw();
    }

    private static void OnAnyChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        => ((LineChart)d).Redraw();

    private Brush Res(string key, Brush fallback) => TryFindResource(key) as Brush ?? fallback;

    private void Redraw()
    {
        _canvas.Children.Clear();

        var width = ActualWidth;
        var height = ActualHeight;
        if (width < 60 || height < 60) return;

        var muted = Res("MutedBrush", Brushes.Gray);
        var grid = Res("ChartGridBrush", Brushes.LightGray);
        var primary = Res("PrimaryBrush", Brushes.MediumPurple);
        var mint = Res("MintBrush", Brushes.MediumAquamarine);
        var surface = Res("SurfaceBrush", Brushes.White);

        var items = ItemsSource?.OfType<ChartPoint>().ToList() ?? new List<ChartPoint>();
        if (items.Count == 0)
        {
            var empty = new TextBlock
            {
                Text = "No price entries logged for this part yet.",
                FontSize = 12.5,
                Foreground = muted,
                Width = width,
                TextAlignment = TextAlignment.Center
            };
            Canvas.SetTop(empty, height / 2 - 10);
            _canvas.Children.Add(empty);
            return;
        }

        const double left = 62, right = 14, top = 16, bottom = 28;
        var plotW = Math.Max(10, width - left - right);
        var plotH = Math.Max(10, height - top - bottom);

        var values = items.Select(i => i.Value).ToList();
        if (TargetValue > 0) values.Add(TargetValue);

        var min = values.Min();
        var max = values.Max();
        if (Math.Abs(max - min) < 0.0001)
        {
            max = max + Math.Max(1, max * 0.1);
            min = Math.Max(0, min - Math.Max(1, min * 0.1));
        }
        var pad = (max - min) * 0.12;
        max += pad;
        min = Math.Max(0, min - pad);

        double X(int index) => items.Count == 1
            ? left + plotW / 2
            : left + plotW * index / (items.Count - 1);

        double Y(double value) => top + plotH - (value - min) / (max - min) * plotH;

        // horizontal grid + value labels
        for (var g = 0; g <= 3; g++)
        {
            var value = min + (max - min) * g / 3.0;
            var y = Y(value);

            _canvas.Children.Add(new Line
            {
                X1 = left, X2 = left + plotW, Y1 = y, Y2 = y,
                Stroke = grid, StrokeThickness = 1
            });

            var label = new TextBlock
            {
                Text = Money.FormatCompact(value),
                FontSize = 10.5,
                Foreground = muted,
                Width = left - 10,
                TextAlignment = TextAlignment.Right
            };
            Canvas.SetLeft(label, 0);
            Canvas.SetTop(label, y - 9);
            _canvas.Children.Add(label);
        }

        // area
        if (items.Count > 1)
        {
            var area = new Polygon
            {
                Fill = primary,
                Opacity = 0.14,
                Points = new PointCollection()
            };
            area.Points.Add(new Point(X(0), top + plotH));
            for (var i = 0; i < items.Count; i++) area.Points.Add(new Point(X(i), Y(items[i].Value)));
            area.Points.Add(new Point(X(items.Count - 1), top + plotH));
            _canvas.Children.Add(area);

            var line = new Polyline
            {
                Stroke = primary,
                StrokeThickness = 2.5,
                StrokeLineJoin = PenLineJoin.Round,
                Points = new PointCollection()
            };
            for (var i = 0; i < items.Count; i++) line.Points.Add(new Point(X(i), Y(items[i].Value)));
            _canvas.Children.Add(line);
        }

        // target line
        if (TargetValue > 0)
        {
            var ty = Y(TargetValue);
            var targetLine = new Line
            {
                X1 = left, X2 = left + plotW, Y1 = ty, Y2 = ty,
                Stroke = mint, StrokeThickness = 1.6,
                StrokeDashArray = new DoubleCollection { 5, 4 }
            };
            _canvas.Children.Add(targetLine);

            var tag = new TextBlock
            {
                Text = "target " + Money.FormatCompact(TargetValue),
                FontSize = 10.5,
                Foreground = muted
            };
            Canvas.SetLeft(tag, left + 4);
            Canvas.SetTop(tag, Math.Max(0, ty - 17));
            _canvas.Children.Add(tag);
        }

        // dots
        for (var i = 0; i < items.Count; i++)
        {
            var dot = new Ellipse
            {
                Width = 9, Height = 9,
                Fill = surface,
                Stroke = primary,
                StrokeThickness = 2.2
            };
            Canvas.SetLeft(dot, X(i) - 4.5);
            Canvas.SetTop(dot, Y(items[i].Value) - 4.5);
            _canvas.Children.Add(dot);
        }

        // x labels: first, middle, last
        var indices = new List<int> { 0 };
        if (items.Count > 2) indices.Add(items.Count / 2);
        if (items.Count > 1) indices.Add(items.Count - 1);

        foreach (var index in indices.Distinct())
        {
            var label = new TextBlock
            {
                Text = items[index].Label,
                FontSize = 10.5,
                Foreground = muted,
                Width = 84,
                TextAlignment = TextAlignment.Center
            };
            Canvas.SetLeft(label, X(index) - 42);
            Canvas.SetTop(label, top + plotH + 8);
            _canvas.Children.Add(label);
        }
    }
}
